--
-- PostgreSQL database dump
--

\restrict CxG3AiBeGwc73KmuLesFVx76P1pr3wCTBDx2O3KfYCvuaBOWhDRBOeX3vpaWXP2

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.work_plans DROP CONSTRAINT IF EXISTS "work_plans_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.work_plans DROP CONSTRAINT IF EXISTS work_plans_type_fkey;
ALTER TABLE IF EXISTS ONLY public.work_plans DROP CONSTRAINT IF EXISTS "work_plans_siteId_fkey";
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS "audit_logs_userId_fkey";
ALTER TABLE IF EXISTS ONLY public."_SiteToType" DROP CONSTRAINT IF EXISTS "_SiteToType_B_fkey";
ALTER TABLE IF EXISTS ONLY public."_SiteToType" DROP CONSTRAINT IF EXISTS "_SiteToType_A_fkey";
DROP INDEX IF EXISTS public."work_plans_userId_startDate_idx";
DROP INDEX IF EXISTS public."work_plans_startDate_endDate_idx";
DROP INDEX IF EXISTS public."work_plans_siteId_idx";
DROP INDEX IF EXISTS public.users_username_key;
DROP INDEX IF EXISTS public.types_name_key;
DROP INDEX IF EXISTS public."audit_logs_userId_createdAt_idx";
DROP INDEX IF EXISTS public."audit_logs_createdAt_idx";
DROP INDEX IF EXISTS public."_SiteToType_B_index";
ALTER TABLE IF EXISTS ONLY public.work_plans DROP CONSTRAINT IF EXISTS work_plans_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.types DROP CONSTRAINT IF EXISTS types_pkey;
ALTER TABLE IF EXISTS ONLY public.sites DROP CONSTRAINT IF EXISTS sites_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_pkey;
ALTER TABLE IF EXISTS ONLY public._prisma_migrations DROP CONSTRAINT IF EXISTS _prisma_migrations_pkey;
ALTER TABLE IF EXISTS ONLY public."_SiteToType" DROP CONSTRAINT IF EXISTS "_SiteToType_AB_pkey";
ALTER TABLE IF EXISTS public.work_plans ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sites ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.work_plans_id_seq;
DROP TABLE IF EXISTS public.work_plans;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.types;
DROP SEQUENCE IF EXISTS public.sites_id_seq;
DROP TABLE IF EXISTS public.sites;
DROP TABLE IF EXISTS public.audit_logs;
DROP TABLE IF EXISTS public._prisma_migrations;
DROP TABLE IF EXISTS public."_SiteToType";
DROP TYPE IF EXISTS public."Role";
--
-- Name: Role; Type: TYPE; Schema: public; Owner: beconnected
--

CREATE TYPE public."Role" AS ENUM (
    'CEO',
    'ENGINEER'
);


ALTER TYPE public."Role" OWNER TO beconnected;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _SiteToType; Type: TABLE; Schema: public; Owner: beconnected
--

CREATE TABLE public."_SiteToType" (
    "A" integer NOT NULL,
    "B" text NOT NULL
);


ALTER TABLE public."_SiteToType" OWNER TO beconnected;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: beconnected
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO beconnected;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: beconnected
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    action text NOT NULL,
    "targetId" text,
    detail jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "userId" integer NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO beconnected;

--
-- Name: sites; Type: TABLE; Schema: public; Owner: beconnected
--

CREATE TABLE public.sites (
    name text NOT NULL,
    id integer NOT NULL
);


ALTER TABLE public.sites OWNER TO beconnected;

--
-- Name: sites_id_seq; Type: SEQUENCE; Schema: public; Owner: beconnected
--

CREATE SEQUENCE public.sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sites_id_seq OWNER TO beconnected;

--
-- Name: sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: beconnected
--

ALTER SEQUENCE public.sites_id_seq OWNED BY public.sites.id;


--
-- Name: types; Type: TABLE; Schema: public; Owner: beconnected
--

CREATE TABLE public.types (
    id text NOT NULL,
    name text NOT NULL
);


ALTER TABLE public.types OWNER TO beconnected;

--
-- Name: users; Type: TABLE; Schema: public; Owner: beconnected
--

CREATE TABLE public.users (
    username text NOT NULL,
    "passwordHash" text NOT NULL,
    name text NOT NULL,
    role public."Role" NOT NULL,
    color text NOT NULL,
    id integer NOT NULL
);


ALTER TABLE public.users OWNER TO beconnected;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: beconnected
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO beconnected;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: beconnected
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: work_plans; Type: TABLE; Schema: public; Owner: beconnected
--

CREATE TABLE public.work_plans (
    "siteId" integer NOT NULL,
    name text NOT NULL,
    "startDate" date NOT NULL,
    "endDate" date NOT NULL,
    "actStart" timestamp(3) without time zone,
    "actEnd" timestamp(3) without time zone,
    "delayStartReason" text,
    "delayEndReason" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    type text,
    id integer NOT NULL,
    "userId" integer NOT NULL
);


ALTER TABLE public.work_plans OWNER TO beconnected;

--
-- Name: work_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: beconnected
--

CREATE SEQUENCE public.work_plans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.work_plans_id_seq OWNER TO beconnected;

--
-- Name: work_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: beconnected
--

ALTER SEQUENCE public.work_plans_id_seq OWNED BY public.work_plans.id;


--
-- Name: sites id; Type: DEFAULT; Schema: public; Owner: beconnected
--

ALTER TABLE ONLY public.sites ALTER COLUMN id SET DEFAULT nextval('public.sites_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: beconnected
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: work_plans id; Type: DEFAULT; Schema: public; Owner: beconnected
--

ALTER TABLE ONLY public.work_plans ALTER COLUMN id SET DEFAULT nextval('public.work_plans_id_seq'::regclass);


--
-- Data for Name: _SiteToType; Type: TABLE DATA; Schema: public; Owner: beconnected
--

COPY public."_SiteToType" ("A", "B") FROM stdin;
1	1
1	2
1	3
2	1
3	5
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: beconnected
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
39b87fef-297c-4d61-b0c3-7b9befc6721f	eb00f0ac7c4faba89d4c49c35c2aa32975cd14013e563752093e29af1ee14501	2026-07-15 09:45:01.098409+00	20260702000000_init	\N	\N	2026-07-15 09:45:01.043948+00	1
2bd26da3-b5db-4c61-bed8-4e4bdfb0e18e	ca4fb62fdf0f5787afebbe81c38c5cfce42eb81a989d35c32f97bcdcf5aa90d4	2026-07-15 09:45:01.321476+00	20260711044237_site_types_implicit_m2m	\N	\N	2026-07-15 09:45:01.30398+00	1
fb29c75f-7126-4ea9-b642-4929503ed5fd	26dc4e28033ef8b64e8ca6863e8cacb7be319e74e5259c30b67e462d22893c64	2026-07-15 09:45:01.102371+00	20260706000000_job_id_sequence	\N	\N	2026-07-15 09:45:01.099451+00	1
a59f0caf-fa86-4642-8b80-d2306dba5a6d	6aa69a054f33fea8c7a3a86079d13b708e70a7eab62e8cec46a06b10f467a8f8	2026-07-15 09:45:01.117022+00	20260707023903_add_audit_log	\N	\N	2026-07-15 09:45:01.103264+00	1
75edf994-6940-43d0-b291-4d2a0fc1f5f7	bcdf804e50d9cb3b5a79ff0eb4bf887d0d2289255faa6d75eccff49f4520b8a2	2026-07-15 09:45:01.121848+00	20260707064110_add_workplan_type	\N	\N	2026-07-15 09:45:01.117919+00	1
3d62cd83-d161-429a-bb3d-761b1bff29cb	96ea2ec2166bd50a5853ac8bb67bfcb761663e3f416fbd98343c65ebbbf12362	2026-07-15 09:45:01.33351+00	20260711074613_link_work_plan_site	\N	\N	2026-07-15 09:45:01.32286+00	1
20e8acd6-8096-42e8-90ec-f1c2a416b32b	122d743a0403e77ad7e0ed9447f5b8826f2fbdbc55612d936eff004dd13c2eec	2026-07-15 09:45:01.1255+00	20260707064119_add_workplan_type	\N	\N	2026-07-15 09:45:01.12303+00	1
295443bf-c01d-4a8b-aff6-f8c69007680f	cd545d55b175b58241ffb0901d2fa88f8e5d0b6da4c8be19d512aed79729eab7	2026-07-15 09:45:01.150112+00	20260709000000_plan_type_table	\N	\N	2026-07-15 09:45:01.126458+00	1
6a54f93a-e17b-4c23-9ce1-ddbd547bf125	76b80f4253e59c7a47939a0ac36631ca1003466facaeef1c3f29a598f254ffb9	2026-07-15 09:45:01.155096+00	20260709070000_plan_type_numeric_ids	\N	\N	2026-07-15 09:45:01.151162+00	1
534022d4-7378-4807-8a31-f2331886cfd6	9cd254abf17ab1039af600ccff21fffb047ea40b5978e11cb5da32dcf1bcb6d9	2026-07-15 09:45:01.189766+00	20260709080000_rename_plan_types_drop_sort_order	\N	\N	2026-07-15 09:45:01.156212+00	1
5a4d79b9-5f3e-4607-9546-b13533244358	a460281c284d2b9af5dfb1168b34ac273b14382fba041e9e5d90f80d1af03477	2026-07-15 09:45:01.202779+00	20260709090000_add_site_table	\N	\N	2026-07-15 09:45:01.191047+00	1
da555466-8e4d-4a83-b030-a711cb82816d	fa6e271ca6c9ad267c796fe0efb87b756a72a67eda02c26fa3b1104c28ea79f1	2026-07-15 09:45:01.21657+00	20260709100000_site_types_many_to_many	\N	\N	2026-07-15 09:45:01.203785+00	1
faeb3493-86bf-4ed9-918b-a9506f828921	9f23066d42abcb8e279aed0bdcc29c3ca97673851d0c2bf8bc688f139af957c1	2026-07-15 09:45:01.220457+00	20260709110000_rename_job_id_to_site_id	\N	\N	2026-07-15 09:45:01.217496+00	1
9bd05ad6-89ab-49ff-9622-a7e2791017ab	33c3a456df3d5a21ad3e1c86094450c5c7c89a2dd7ad342a7b97e6fc3aa8dbb0	2026-07-15 09:45:01.28216+00	20260710000000_numeric_run_ids	\N	\N	2026-07-15 09:45:01.221496+00	1
06518e56-abd5-456c-8de6-86fc9e5f9a7b	ffb7cb6924580f3349fc82d48732726f05e8a9b98cb5dd7a187ce7284030b638	2026-07-15 09:45:01.302997+00	20260711000000_numeric_user_ids	\N	\N	2026-07-15 09:45:01.283196+00	1
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: beconnected
--

COPY public.audit_logs (id, action, "targetId", detail, "createdAt", "userId") FROM stdin;
cmrlwyya90001n43sihxvuntb	auth.login	\N	\N	2026-07-15 10:05:01.329	2
cmrlx9b1i0003n43sk95xz6lb	auth.login	\N	\N	2026-07-15 10:13:04.422	3
cmrlx9c510004n43sty7c92yp	ui.click	\N	{"at": "2026-07-15T10:13:03.956Z", "tag": "button", "page": "/", "label": "เข้าสู่ระบบ"}	2026-07-15 10:13:05.846	3
cmrlxbvg40006n43se6sg9hx8	auth.login	\N	\N	2026-07-15 10:15:04.181	2
cmrlxbwk40007n43s6eyugq9j	ui.click	\N	{"at": "2026-07-15T10:15:01.763Z", "tag": "button", "page": "/", "label": "เข้าสู่ระบบ"}	2026-07-15 10:15:05.62	2
cmrlxc3gs0008n43svly0soko	ui.click	\N	{"at": "2026-07-15T10:15:04.256Z", "tag": "nav.nav", "page": "/dashboard", "label": "งานของฉันไซต์งานประวัติการใช้งานคลังอุปกรณ์ยืม-คืนลงเวลาลา"}	2026-07-15 10:15:14.572	2
cmrlxc3gs0009n43sk7xrjktp	ui.click	\N	{"at": "2026-07-15T10:15:04.662Z", "tag": "a.nav-item", "page": "/dashboard", "label": "ไซต์งาน"}	2026-07-15 10:15:14.572	2
cmrlxc3gs000an43sc3i65uto	ui.click	\N	{"at": "2026-07-15T10:15:05.086Z", "tag": "a.nav-item", "page": "/sites", "label": "ประวัติการใช้งาน"}	2026-07-15 10:15:14.572	2
cmrlxc3gs000bn43sxwme6b2i	ui.click	\N	{"at": "2026-07-15T10:15:05.550Z", "tag": "div.nav-item", "page": "/logs", "label": "คลังอุปกรณ์"}	2026-07-15 10:15:14.572	2
cmrlxc3gs000cn43s08q0j65c	ui.click	\N	{"at": "2026-07-15T10:15:05.918Z", "tag": "a.nav-item", "page": "/logs", "label": "ประวัติการใช้งาน"}	2026-07-15 10:15:14.572	2
cmrlxc3gs000dn43si68p9fzq	ui.click	\N	{"at": "2026-07-15T10:15:06.269Z", "tag": "a.nav-item", "page": "/logs", "label": "ไซต์งาน"}	2026-07-15 10:15:14.572	2
cmrlxc3gs000en43ssxxfwv1w	ui.click	\N	{"at": "2026-07-15T10:15:06.970Z", "tag": "button.btn-primary", "page": "/sites", "label": "+ ไซต์งาน"}	2026-07-15 10:15:14.572	2
cmrlxc3gs000fn43sewzmr5fs	ui.click	\N	{"at": "2026-07-15T10:15:08.062Z", "tag": "label.check-item", "page": "/sites", "label": "Solar Cell"}	2026-07-15 10:15:14.572	2
cmrlxc3gs000gn43s73lbj7kz	ui.click	\N	{"at": "2026-07-15T10:15:08.062Z", "tag": "input", "page": "/sites", "label": "INPUT"}	2026-07-15 10:15:14.572	2
cmrlxc3gs000hn43sihemv6sm	ui.click	\N	{"at": "2026-07-15T10:15:08.356Z", "tag": "label.check-item", "page": "/sites", "label": "Network"}	2026-07-15 10:15:14.572	2
cmrlxc3gs000in43sitvnjf6j	ui.click	\N	{"at": "2026-07-15T10:15:08.356Z", "tag": "input", "page": "/sites", "label": "INPUT"}	2026-07-15 10:15:14.572	2
cmrlxc3gs000jn43siwtpxfba	ui.click	\N	{"at": "2026-07-15T10:15:08.728Z", "tag": "label.check-item", "page": "/sites", "label": "Software"}	2026-07-15 10:15:14.572	2
cmrlxc3gs000kn43s8iunqex2	ui.click	\N	{"at": "2026-07-15T10:15:08.729Z", "tag": "input", "page": "/sites", "label": "INPUT"}	2026-07-15 10:15:14.572	2
cmrlxc3gs000ln43sf793y5h6	ui.click	\N	{"at": "2026-07-15T10:15:09.245Z", "tag": "button.btn-ghost", "page": "/sites", "label": "ยกเลิก"}	2026-07-15 10:15:14.572	2
cmrlxc3gs000mn43s909re7vl	ui.click	\N	{"at": "2026-07-15T10:15:10.163Z", "tag": "div.nav-item", "page": "/sites", "label": "ลา"}	2026-07-15 10:15:14.572	2
cmrlxc3gs000nn43sgw4hen1f	ui.click	\N	{"at": "2026-07-15T10:15:10.571Z", "tag": "div.nav-item", "page": "/sites", "label": "ลา"}	2026-07-15 10:15:14.572	2
cmrlxc3gs000on43s7ztiw8ko	ui.click	\N	{"at": "2026-07-15T10:15:11.071Z", "tag": "div.nav-item", "page": "/sites", "label": "ลา"}	2026-07-15 10:15:14.572	2
cmrlxc3gs000pn43s6zz5325x	ui.click	\N	{"at": "2026-07-15T10:15:11.472Z", "tag": "div.nav-item", "page": "/sites", "label": "ลา"}	2026-07-15 10:15:14.572	2
cmrlxc3gs000qn43snwu53dye	ui.click	\N	{"at": "2026-07-15T10:15:11.896Z", "tag": "div.nav-item", "page": "/sites", "label": "ลา"}	2026-07-15 10:15:14.572	2
cmrlxc3gs000rn43suzaws9lp	ui.click	\N	{"at": "2026-07-15T10:15:12.211Z", "tag": "nav.nav", "page": "/sites", "label": "งานของฉันไซต์งานประวัติการใช้งานคลังอุปกรณ์ยืม-คืนลงเวลาลา"}	2026-07-15 10:15:14.572	2
cmrmxd19s000tn43ss5jrtp9s	auth.login	\N	\N	2026-07-16 03:03:44.56	4
cmrmxd2ce000un43s99fhba2b	ui.click	\N	{"at": "2026-07-16T03:03:41.104Z", "tag": "button", "page": "/", "label": "เข้าสู่ระบบ"}	2026-07-16 03:03:45.951	4
cmrmxda1v000vn43s5mkhd8xk	ui.click	\N	{"at": "2026-07-16T03:03:51.093Z", "tag": "a.nav-item", "page": "/dashboard", "label": "ไซต์งาน"}	2026-07-16 03:03:55.939	4
cmrmxdgy4000wn43s44bhwjqo	ui.click	\N	{"at": "2026-07-16T03:03:53.981Z", "tag": "button.type-btn", "page": "/sites", "label": "Solar Cell"}	2026-07-16 03:04:04.875	4
cmrmxdgy4000xn43sl8bhp9e9	ui.click	\N	{"at": "2026-07-16T03:03:54.824Z", "tag": "button.type-btn", "page": "/sites", "label": "CCTV"}	2026-07-16 03:04:04.875	4
cmrmxdgy4000yn43sbw68s4g4	ui.click	\N	{"at": "2026-07-16T03:03:55.250Z", "tag": "button.type-btn", "page": "/sites", "label": "Network"}	2026-07-16 03:04:04.875	4
cmrmxdgy4000zn43sy83ocbqs	ui.click	\N	{"at": "2026-07-16T03:03:55.667Z", "tag": "div.type-filter", "page": "/sites", "label": "ทั้งหมดSolar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:04:04.875	4
cmrmxdgy40010n43sy3j00o1i	ui.click	\N	{"at": "2026-07-16T03:03:56.021Z", "tag": "button.type-btn", "page": "/sites", "label": "Software"}	2026-07-16 03:04:04.875	4
cmrmxdgy40011n43sya98qxm5	ui.click	\N	{"at": "2026-07-16T03:03:56.486Z", "tag": "button.type-btn", "page": "/sites", "label": "IOT"}	2026-07-16 03:04:04.875	4
cmrmxdgy40012n43srdifpy6z	ui.click	\N	{"at": "2026-07-16T03:03:57.048Z", "tag": "button.type-btn", "page": "/sites", "label": "Network"}	2026-07-16 03:04:04.875	4
cmrmxdgy40013n43s8qvzutak	ui.click	\N	{"at": "2026-07-16T03:03:57.524Z", "tag": "button.type-btn", "page": "/sites", "label": "CCTV"}	2026-07-16 03:04:04.875	4
cmrmxdgy40014n43sxk6gl9dt	ui.click	\N	{"at": "2026-07-16T03:03:57.932Z", "tag": "button.type-btn", "page": "/sites", "label": "Solar Cell"}	2026-07-16 03:04:04.875	4
cmrmxdgy40015n43s9eqss8m0	ui.click	\N	{"at": "2026-07-16T03:03:59.376Z", "tag": "button.type-btn", "page": "/sites", "label": "ทั้งหมด"}	2026-07-16 03:04:04.875	4
cmrmxdgy40016n43sf7s9dl6j	ui.click	\N	{"at": "2026-07-16T03:03:59.985Z", "tag": "button.type-btn", "page": "/sites", "label": "Solar Cell"}	2026-07-16 03:04:04.875	4
cmrmxdiv20017n43s9p21n15p	ui.click	\N	{"at": "2026-07-16T03:04:02.524Z", "tag": "button.btn-primary", "page": "/sites", "label": "+ ไซต์งาน"}	2026-07-16 03:04:07.359	4
cmrmxdka50018n43sekb0jse4	ui.click	\N	{"at": "2026-07-16T03:04:04.361Z", "tag": "input", "page": "/sites", "label": "INPUT"}	2026-07-16 03:04:09.197	4
cmrmxdq900019n43sq2c12yea	ui.click	\N	{"at": "2026-07-16T03:04:09.026Z", "tag": "input", "page": "/sites", "label": "INPUT"}	2026-07-16 03:04:16.933	4
cmrmxdq90001an43s91l5bkk2	ui.click	\N	{"at": "2026-07-16T03:04:10.035Z", "tag": "input", "page": "/sites", "label": "INPUT"}	2026-07-16 03:04:16.933	4
cmrmxdq90001bn43syi0gdphi	ui.click	\N	{"at": "2026-07-16T03:04:10.456Z", "tag": "input", "page": "/sites", "label": "INPUT"}	2026-07-16 03:04:16.933	4
cmrmxdq90001cn43sf2uy9i4n	ui.click	\N	{"at": "2026-07-16T03:04:11.732Z", "tag": "input", "page": "/sites", "label": "INPUT"}	2026-07-16 03:04:16.933	4
cmrmxdq90001dn43skn5yxyui	ui.click	\N	{"at": "2026-07-16T03:04:12.085Z", "tag": "input", "page": "/sites", "label": "INPUT"}	2026-07-16 03:04:16.933	4
cmrmxdxzu001en43s9pjwnric	ui.click	\N	{"at": "2026-07-16T03:04:18.798Z", "tag": "input", "page": "/sites", "label": "INPUT"}	2026-07-16 03:04:26.97	4
cmrmxdxzu001fn43stahocnk9	ui.click	\N	{"at": "2026-07-16T03:04:19.177Z", "tag": "input", "page": "/sites", "label": "INPUT"}	2026-07-16 03:04:26.97	4
cmrmxdxzu001gn43ssjd8067o	ui.click	\N	{"at": "2026-07-16T03:04:19.553Z", "tag": "label.check-item", "page": "/sites", "label": "CCTV"}	2026-07-16 03:04:26.97	4
cmrmxdxzu001hn43si0hllxcv	ui.click	\N	{"at": "2026-07-16T03:04:19.553Z", "tag": "input", "page": "/sites", "label": "INPUT"}	2026-07-16 03:04:26.97	4
cmrmxdxzu001in43sepzs415p	ui.click	\N	{"at": "2026-07-16T03:04:20.071Z", "tag": "input", "page": "/sites", "label": "INPUT"}	2026-07-16 03:04:26.97	4
cmrmxdxzu001jn43s32tij26h	ui.click	\N	{"at": "2026-07-16T03:04:21.036Z", "tag": "input", "page": "/sites", "label": "INPUT"}	2026-07-16 03:04:26.97	4
cmrmxdxzu001kn43sug2nieba	ui.click	\N	{"at": "2026-07-16T03:04:22.122Z", "tag": "button.btn-primary", "page": "/sites", "label": "บันทึกไซต์งาน"}	2026-07-16 03:04:26.97	4
cmrmxdz5b001ln43st86sz9ji	ui.click	\N	{"at": "2026-07-16T03:04:23.626Z", "tag": "input", "page": "/sites", "label": "INPUT"}	2026-07-16 03:04:28.464	4
cmrmxe04b001nn43s1riq59p5	site.create	1	{"name": "0080", "typeIds": ["1", "3", "2"]}	2026-07-16 03:04:29.723	4
cmrmxe3as001on43si32795wb	ui.click	\N	{"at": "2026-07-16T03:04:26.358Z", "tag": "button.btn-primary", "page": "/sites", "label": "บันทึกไซต์งาน"}	2026-07-16 03:04:33.844	4
cmrmxe3as001pn43sni8aa0ng	ui.click	\N	{"at": "2026-07-16T03:04:27.825Z", "tag": "button.btn-primary", "page": "/sites", "label": "ปิด"}	2026-07-16 03:04:33.844	4
cmrmxe3as001qn43snjsk7o7e	ui.click	\N	{"at": "2026-07-16T03:04:29.004Z", "tag": "a.plan-row", "page": "/sites", "label": "0080Solar CellCCTVNetwork›"}	2026-07-16 03:04:33.844	4
cmrmxe706001rn43scuaed7y7	ui.click	\N	{"at": "2026-07-16T03:04:31.707Z", "tag": "p.empty-note", "page": "/sites/1", "label": "ยังไม่มีแผนงานในไซต์นี้"}	2026-07-16 03:04:38.647	4
cmrmxe706001sn43sc79elw1q	ui.click	\N	{"at": "2026-07-16T03:04:32.479Z", "tag": "button.title-edit", "page": "/sites/1", "label": "แก้ไขชื่อไซต์"}	2026-07-16 03:04:38.647	4
cmrmxe706001tn43stgynwdyu	ui.click	\N	{"at": "2026-07-16T03:04:33.805Z", "tag": "button.btn-ghost", "page": "/sites/1", "label": "ยกเลิก"}	2026-07-16 03:04:38.647	4
cmrmxe89i001un43sp7cafb5h	ui.click	\N	{"at": "2026-07-16T03:04:35.437Z", "tag": "button.btn-danger", "page": "/sites/1", "label": "ลบไซต์งาน"}	2026-07-16 03:04:40.278	4
cmrmxeajo001vn43sy21prfne	ui.click	\N	{"at": "2026-07-16T03:04:37.578Z", "tag": "div.panel-head", "page": "/sites/1", "label": "0080Solar CellCCTVNetworkยืนยันลบไซต์นี้?"}	2026-07-16 03:04:43.236	4
cmrmxeajo001wn43sgeuz4xo4	ui.click	\N	{"at": "2026-07-16T03:04:38.394Z", "tag": "p.empty-note", "page": "/sites/1", "label": "ยังไม่มีแผนงานในไซต์นี้"}	2026-07-16 03:04:43.236	4
cmrmxec3m001xn43se46acndv	ui.click	\N	{"at": "2026-07-16T03:04:40.410Z", "tag": "p.empty-note", "page": "/sites/1", "label": "ยังไม่มีแผนงานในไซต์นี้"}	2026-07-16 03:04:45.25	4
cmrmxedge001yn43sk6wy9s68	ui.click	\N	{"at": "2026-07-16T03:04:42.163Z", "tag": "a.nav-item", "page": "/sites/1", "label": "งานของฉัน"}	2026-07-16 03:04:47.007	4
cmrmxeg6e001zn43s85vbw0lc	ui.click	\N	{"at": "2026-07-16T03:04:44.987Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "+ เพิ่มแผน"}	2026-07-16 03:04:50.534	4
cmrmxeg6e0020n43syixyz54i	ui.click	\N	{"at": "2026-07-16T03:04:45.675Z", "tag": "div.overlay", "page": "/dashboard", "label": "เพิ่มแผนงานชื่อแผนงานประเภทงาน— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:04:50.534	4
cmrmxeiey0021n43s4oaxealv	ui.click	\N	{"at": "2026-07-16T03:04:47.455Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "+ เพิ่มแผน"}	2026-07-16 03:04:53.434	4
cmrmxeiey0022n43snx7oixfu	ui.click	\N	{"at": "2026-07-16T03:04:48.590Z", "tag": "input", "page": "/dashboard", "label": "INPUT"}	2026-07-16 03:04:53.434	4
cmrmxeqk00023n43s3pj51oq2	ui.click	\N	{"at": "2026-07-16T03:04:57.727Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:05:03.984	4
cmrmxeqk00024n43sq02r5jov	ui.click	\N	{"at": "2026-07-16T03:04:59.099Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:05:03.984	4
cmrmxes9o0025n43sehfaqb6i	ui.click	\N	{"at": "2026-07-16T03:05:01.361Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080"}	2026-07-16 03:05:06.204	4
cmrmxett70026n43s8vn9f9o0	ui.click	\N	{"at": "2026-07-16T03:05:03.354Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080"}	2026-07-16 03:05:08.204	4
cmrmxev6f0027n43sxx9asnhk	ui.click	\N	{"at": "2026-07-16T03:05:05.100Z", "tag": "form.modal", "page": "/dashboard", "label": "เพิ่มแผนงานชื่อแผนงานประเภทงาน— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:05:09.975	4
cmrmxf4v60028n43sz1dodv7v	ui.click	\N	{"at": "2026-07-16T03:05:16.534Z", "tag": "input", "page": "/dashboard", "label": "INPUT"}	2026-07-16 03:05:22.53	4
cmrmxf4v60029n43san7uo4pu	ui.click	\N	{"at": "2026-07-16T03:05:17.632Z", "tag": "input", "page": "/dashboard", "label": "INPUT"}	2026-07-16 03:05:22.53	4
cmrmxf8m5002bn43s41927tsa	workPlan.create	1	{"name": "กำลัง", "type": "1", "siteId": 1, "endDate": "2026-07-17T00:00:00.000Z", "startDate": "2026-07-16T00:00:00.000Z"}	2026-07-16 03:05:27.389	4
cmrmxf9ra002cn43s38tkj9z2	ui.click	\N	{"at": "2026-07-16T03:05:24.018Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "บันทึกแผน"}	2026-07-16 03:05:28.87	4
cmrmxfd4p002dn43sr42p9rbg	ui.click	\N	{"at": "2026-07-16T03:05:26.368Z", "tag": "span.cal-bar", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:05:33.241	4
cmrmxfd4p002en43sxjcwzrr8	ui.click	\N	{"at": "2026-07-16T03:05:27.711Z", "tag": "span.cal-bar", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:05:33.241	4
cmrmxfd4p002fn43spz6ep0fz	ui.click	\N	{"at": "2026-07-16T03:05:28.389Z", "tag": "span.cal-bar", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:05:33.241	4
cmrmxffkp002gn43sn88c3dtz	ui.click	\N	{"at": "2026-07-16T03:05:30.329Z", "tag": "div.plan-row", "page": "/dashboard", "label": "กำลัง16/07/2026 – 17/07/2026Solar Cellยังไม่เริ่ม"}	2026-07-16 03:05:36.41	4
cmrmxffkp002hn43s9lqvn9e3	ui.click	\N	{"at": "2026-07-16T03:05:31.556Z", "tag": "div.plan-sub", "page": "/dashboard", "label": "16/07/2026 – 17/07/2026"}	2026-07-16 03:05:36.41	4
cmrmxfh6z002in43sc0ir1i0n	ui.click	\N	{"at": "2026-07-16T03:05:33.382Z", "tag": "h2", "page": "/dashboard", "label": "แผนงานเดือนกรกฎาคม 2026"}	2026-07-16 03:05:38.507	4
cmrmxfh6z002jn43samip9atv	ui.click	\N	{"at": "2026-07-16T03:05:33.654Z", "tag": "section.day-panel", "page": "/dashboard", "label": "แผนงานเดือนกรกฎาคม 2026+ เพิ่มแผนกำลัง16/07/2026 – 17/07/2026Solar Cellยังไม่เริ"}	2026-07-16 03:05:38.507	4
cmrmxfir7002kn43svysk3yzg	ui.click	\N	{"at": "2026-07-16T03:05:35.682Z", "tag": "div.plan-row", "page": "/dashboard", "label": "กำลัง16/07/2026 – 17/07/2026Solar Cellยังไม่เริ่มแก้ไข"}	2026-07-16 03:05:40.531	4
cmrmxfkdd002ln43s89cmy4mm	ui.click	\N	{"at": "2026-07-16T03:05:37.763Z", "tag": "div.panel-head", "page": "/dashboard", "label": "แผนงานเดือนกรกฎาคม 2026+ เพิ่มแผน"}	2026-07-16 03:05:42.626	4
cmrmxfvn2002nn43sqgxaa71u	workPlan.start	1	{"id": 1}	2026-07-16 03:05:57.23	4
cmrmxfwsu002on43s6t6gc27u	ui.click	\N	{"at": "2026-07-16T03:05:53.859Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "เริ่มงาน"}	2026-07-16 03:05:58.734	4
cmrmxg36j002pn43s8uuks4bj	ui.click	\N	{"at": "2026-07-16T03:06:00.169Z", "tag": "span.cal-bar", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:06:07.003	4
cmrmxg36j002qn43s55os3sia	ui.click	\N	{"at": "2026-07-16T03:06:01.444Z", "tag": "span.cal-bar", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:06:07.003	4
cmrmxg36j002rn43s7uzcycu1	ui.click	\N	{"at": "2026-07-16T03:06:01.612Z", "tag": "span.cal-bar", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:06:07.003	4
cmrmxg36j002sn43s4gu08zi2	ui.click	\N	{"at": "2026-07-16T03:06:02.152Z", "tag": "span.cal-bar", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:06:07.003	4
cmrmxg6tz002tn43sl5zx2iju	ui.click	\N	{"at": "2026-07-16T03:06:05.937Z", "tag": "div.plan-name", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:06:11.736	4
cmrmxg6tz002un43suop4mmsb	ui.click	\N	{"at": "2026-07-16T03:06:06.337Z", "tag": "div.plan-name", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:06:11.736	4
cmrmxg6tz002vn43smc6f4ys7	ui.click	\N	{"at": "2026-07-16T03:06:06.566Z", "tag": "div.plan-name", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:06:11.736	4
cmrmxg6tz002wn43spfvtx87a	ui.click	\N	{"at": "2026-07-16T03:06:06.890Z", "tag": "div.plan-name", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:06:11.736	4
cmrmxgaim002xn43sdoxka7ok	ui.click	\N	{"at": "2026-07-16T03:06:08.900Z", "tag": "div.panel-head", "page": "/dashboard", "label": "แผนงานเดือนกรกฎาคม 2026+ เพิ่มแผน"}	2026-07-16 03:06:16.511	4
cmrmxgaim002yn43shzz45qkr	ui.click	\N	{"at": "2026-07-16T03:06:09.222Z", "tag": "div.plan-sub", "page": "/dashboard", "label": "16/07/2026 – 17/07/2026"}	2026-07-16 03:06:16.511	4
cmrmxgaim002zn43setq72rhk	ui.click	\N	{"at": "2026-07-16T03:06:09.436Z", "tag": "div.plan-main", "page": "/dashboard", "label": "กำลัง16/07/2026 – 17/07/2026"}	2026-07-16 03:06:16.511	4
cmrmxgain0030n43suj976tjm	ui.click	\N	{"at": "2026-07-16T03:06:09.772Z", "tag": "div.plan-name", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:06:16.511	4
cmrmxgain0031n43s3ewnvn91	ui.click	\N	{"at": "2026-07-16T03:06:10.007Z", "tag": "div.plan-name", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:06:16.511	4
cmrmxgain0032n43s7yr35ydk	ui.click	\N	{"at": "2026-07-16T03:06:10.195Z", "tag": "div.plan-name", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:06:16.511	4
cmrmxgain0033n43seeakg3nu	ui.click	\N	{"at": "2026-07-16T03:06:10.595Z", "tag": "div.plan-name", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:06:16.511	4
cmrmxgain0034n43s0ih0fw6z	ui.click	\N	{"at": "2026-07-16T03:06:11.589Z", "tag": "div.plan-name", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:06:16.511	4
cmrmxh2u20035n43scxezkazy	ui.click	\N	{"at": "2026-07-16T03:06:47.679Z", "tag": "div.plan-row", "page": "/dashboard", "label": "กำลัง16/07/2026 – 17/07/2026Solar Cellกำลังทำ"}	2026-07-16 03:06:53.21	4
cmrmxh2u20036n43s8yzqfaki	ui.click	\N	{"at": "2026-07-16T03:06:48.299Z", "tag": "div.plan-name", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:06:53.21	4
cmrmxhzco0038n43sly05k8wh	workPlan.finish	1	{"id": 1}	2026-07-16 03:07:35.352	4
cmrmxi0hq0039n43ssenoqa97	ui.click	\N	{"at": "2026-07-16T03:07:31.963Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "จบงาน"}	2026-07-16 03:07:36.831	4
cmrmxkwi8003an43seoy1lfmu	ui.click	\N	{"at": "2026-07-16T03:09:46.766Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "+ เพิ่มแผน"}	2026-07-16 03:09:51.633	4
cmrmxkylz003bn43svgpao12h	ui.click	\N	{"at": "2026-07-16T03:09:49.494Z", "tag": "input", "page": "/dashboard", "label": "INPUT"}	2026-07-16 03:09:54.359	4
cmrmxl4tc003cn43sbtw440ek	ui.click	\N	{"at": "2026-07-16T03:09:55.612Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:10:02.4	4
cmrmxl4tc003dn43swdnp7s1g	ui.click	\N	{"at": "2026-07-16T03:09:56.546Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:10:02.4	4
cmrmxl4tc003en43s7khre70q	ui.click	\N	{"at": "2026-07-16T03:09:57.532Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:10:02.4	4
cmrmxl8gv003fn43sqltjowqb	ui.click	\N	{"at": "2026-07-16T03:09:59.270Z", "tag": "form.modal", "page": "/dashboard", "label": "เพิ่มแผนงานชื่อแผนงานประเภทงาน— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:10:07.135	4
cmrmxl8gv003gn43s274mph96	ui.click	\N	{"at": "2026-07-16T03:09:59.936Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:10:07.135	4
cmrmxzw93004jn43s9kvjbljo	ui.click	\N	{"at": "2026-07-16T03:21:26.189Z", "tag": "span.cal-bar", "page": "/dashboard", "label": "ผรม ลา"}	2026-07-16 03:21:31.143	4
cmrmxl8gv003hn43s6sr4o9sn	ui.click	\N	{"at": "2026-07-16T03:10:00.644Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:10:07.135	4
cmrmxl8gv003in43sk9ebeqzx	ui.click	\N	{"at": "2026-07-16T03:10:01.641Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080"}	2026-07-16 03:10:07.135	4
cmrmxl8gv003jn43sqoyjhysw	ui.click	\N	{"at": "2026-07-16T03:10:02.263Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080"}	2026-07-16 03:10:07.135	4
cmrmxlaal003kn43stoyxpruj	ui.click	\N	{"at": "2026-07-16T03:10:03.921Z", "tag": "input", "page": "/dashboard", "label": "INPUT"}	2026-07-16 03:10:09.502	4
cmrmxlaal003ln43sqq6bezag	ui.click	\N	{"at": "2026-07-16T03:10:04.637Z", "tag": "input", "page": "/dashboard", "label": "INPUT"}	2026-07-16 03:10:09.502	4
cmrmxlbli003nn43sx0b9ay3c	workPlan.create	2	{"name": "ผรม ลา", "type": "2", "siteId": 1, "endDate": "2026-07-17T00:00:00.000Z", "startDate": "2026-07-16T00:00:00.000Z"}	2026-07-16 03:10:11.191	4
cmrmxlcqq003on43safhnwrhp	ui.click	\N	{"at": "2026-07-16T03:10:07.817Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "บันทึกแผน"}	2026-07-16 03:10:12.674	4
cmrmxloa6003pn43s4b69y0lr	ui.click	\N	{"at": "2026-07-16T03:10:22.735Z", "tag": "span.cal-bar", "page": "/dashboard", "label": "ผรม ลา"}	2026-07-16 03:10:27.63	4
cmrmxm1s9003qn43sjir7u6yb	ui.click	\N	{"at": "2026-07-16T03:10:38.084Z", "tag": "a.nav-item", "page": "/dashboard", "label": "ไซต์งาน"}	2026-07-16 03:10:45.129	4
cmrmxm1s9003rn43sa7v74klv	ui.click	\N	{"at": "2026-07-16T03:10:39.440Z", "tag": "button.type-btn", "page": "/sites", "label": "Solar Cell"}	2026-07-16 03:10:45.129	4
cmrmxm1s9003sn43s8riw8vc6	ui.click	\N	{"at": "2026-07-16T03:10:40.256Z", "tag": "a.nav-item", "page": "/sites", "label": "งานของฉัน"}	2026-07-16 03:10:45.129	4
cmrmxmnfi003tn43s4rwthcoz	ui.click	\N	{"at": "2026-07-16T03:11:08.295Z", "tag": "span.cal-bar", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:11:13.182	4
cmrmxmqxo003un43s5sfsn3oq	ui.click	\N	{"at": "2026-07-16T03:11:11.790Z", "tag": "div.plan-main", "page": "/dashboard", "label": "ผรม ลา16/07/2026 – 17/07/2026"}	2026-07-16 03:11:17.724	4
cmrmxmqxo003vn43sfke3icw2	ui.click	\N	{"at": "2026-07-16T03:11:12.850Z", "tag": "button.btn-ghost", "page": "/dashboard", "label": "แก้ไข"}	2026-07-16 03:11:17.724	4
cmrmxmsv0003wn43shbwc53sc	ui.click	\N	{"at": "2026-07-16T03:11:15.338Z", "tag": "button.btn-ghost", "page": "/dashboard", "label": "ยกเลิก"}	2026-07-16 03:11:20.22	4
cmrmxoiqt003xn43swto8ni2s	ui.click	\N	{"at": "2026-07-16T03:12:31.633Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "24"}	2026-07-16 03:12:40.422	4
cmrmxoiqt003yn43s29dccg5p	ui.click	\N	{"at": "2026-07-16T03:12:32.766Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "+ เพิ่มแผน"}	2026-07-16 03:12:40.422	4
cmrmxoiqt003zn43s2byrv9ss	ui.click	\N	{"at": "2026-07-16T03:12:33.816Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:12:40.422	4
cmrmxoiqt0040n43socz94r2u	ui.click	\N	{"at": "2026-07-16T03:12:34.382Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:12:40.422	4
cmrmxoiqt0041n43sjlu2i0ys	ui.click	\N	{"at": "2026-07-16T03:12:35.546Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "บันทึกแผน"}	2026-07-16 03:12:40.422	4
cmrmxokyi0043n43s3b77bs7q	workPlan.create	3	{"name": "000", "type": "2", "siteId": 1, "endDate": "2026-07-24T00:00:00.000Z", "startDate": "2026-07-24T00:00:00.000Z"}	2026-07-16 03:12:43.29	4
cmrmxom450044n43s26cu2k60	ui.click	\N	{"at": "2026-07-16T03:12:37.420Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "บันทึกแผน"}	2026-07-16 03:12:44.79	4
cmrmxom450045n43srp95nywz	ui.click	\N	{"at": "2026-07-16T03:12:38.585Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080"}	2026-07-16 03:12:44.79	4
cmrmxom450046n43sa3wef7qv	ui.click	\N	{"at": "2026-07-16T03:12:39.140Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080"}	2026-07-16 03:12:44.79	4
cmrmxom450047n43st6msyusr	ui.click	\N	{"at": "2026-07-16T03:12:39.908Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "บันทึกแผน"}	2026-07-16 03:12:44.79	4
cmrmxot9n0048n43spxzmhaga	ui.click	\N	{"at": "2026-07-16T03:12:49.184Z", "tag": "span.cal-bar", "page": "/dashboard", "label": "000"}	2026-07-16 03:12:54.059	4
cmrmxp7gp0049n43s8beah9n8	ui.click	\N	{"at": "2026-07-16T03:13:07.564Z", "tag": "div.month-nav", "page": "/dashboard", "label": "«กรกฎาคม 2026»"}	2026-07-16 03:13:12.457	4
cmrmxs020004an43sy471rs9n	ui.click	\N	{"at": "2026-07-16T03:15:17.925Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "+ เพิ่มแผน"}	2026-07-16 03:15:22.825	4
cmrmxs2uo004bn43s9gply02j	ui.click	\N	{"at": "2026-07-16T03:15:21.550Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:15:26.448	4
cmrmxs7nv004cn43s478yvolh	ui.click	\N	{"at": "2026-07-16T03:15:27.791Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:15:32.684	4
cmrmxu8kh004dn43sbtojrhmi	ui.click	\N	{"at": "2026-07-16T03:17:01.988Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:17:07.169	4
cmrmxv5gf004en43s99sk1kal	ui.click	\N	{"at": "2026-07-16T03:17:44.882Z", "tag": "div.overlay", "page": "/dashboard", "label": "เพิ่มแผนงานชื่อแผนงานประเภทงาน— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:17:49.791	4
cmrmxv9cb004fn43so2gj8p4x	ui.click	\N	{"at": "2026-07-16T03:17:49.921Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "+ เพิ่มแผน"}	2026-07-16 03:17:54.828	4
cmrmxvb67004gn43smr6xsgyg	ui.click	\N	{"at": "2026-07-16T03:17:52.298Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:17:57.2	4
cmrmxzua0004hn43s5dprwpoz	ui.click	\N	{"at": "2026-07-16T03:21:23.668Z", "tag": "div.overlay", "page": "/dashboard", "label": "เพิ่มแผนงานชื่อแผนงานประเภทงาน— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:21:28.584	4
cmrmxzw92004in43s5lb7aafn	ui.click	\N	{"at": "2026-07-16T03:21:25.249Z", "tag": "span.cal-bar", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:21:31.143	4
cmrmy03kw004kn43scpddv414	ui.click	\N	{"at": "2026-07-16T03:21:35.708Z", "tag": "a.nav-item", "page": "/dashboard", "label": "ไซต์งาน"}	2026-07-16 03:21:40.641	4
cmrmy04xq004ln43sz4m09leg	ui.click	\N	{"at": "2026-07-16T03:21:37.493Z", "tag": "button.type-btn", "page": "/sites", "label": "Solar Cell"}	2026-07-16 03:21:42.398	4
cmrmy06pv004mn43s0cyp3l6a	ui.click	\N	{"at": "2026-07-16T03:21:39.798Z", "tag": "a.nav-item", "page": "/sites", "label": "งานของฉัน"}	2026-07-16 03:21:44.708	4
cmrmy0u7w004nn43s8495iwt0	ui.click	\N	{"at": "2026-07-16T03:22:10.241Z", "tag": "span.cal-bar", "page": "/dashboard", "label": "กำลัง"}	2026-07-16 03:22:15.164	4
cmrmy14nj004on43sqmnerkw0	ui.click	\N	{"at": "2026-07-16T03:22:23.137Z", "tag": "span.cal-bar", "page": "/dashboard", "label": "ผรม ลา"}	2026-07-16 03:22:28.687	4
cmrmy14nj004pn43sj103ufxs	ui.click	\N	{"at": "2026-07-16T03:22:23.768Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "16"}	2026-07-16 03:22:28.687	4
cmrmy17ga004qn43sqwtbzhda	ui.click	\N	{"at": "2026-07-16T03:22:27.406Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "+ เพิ่มแผน"}	2026-07-16 03:22:32.315	4
cmrmy19l8004rn43sgeeebpi5	ui.click	\N	{"at": "2026-07-16T03:22:30.170Z", "tag": "input", "page": "/dashboard", "label": "INPUT"}	2026-07-16 03:22:35.085	4
cmrmy1dll004tn43s5ua8hpwf	workPlan.create	4	{"name": "0000", "type": "3", "siteId": 1, "endDate": "2026-07-16T00:00:00.000Z", "startDate": "2026-07-16T00:00:00.000Z"}	2026-07-16 03:22:40.281	4
cmrmy1eqz004un43sjwxvrx9e	ui.click	\N	{"at": "2026-07-16T03:22:32.905Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:22:41.771	4
cmrmy1eqz004vn43s2dvzrxus	ui.click	\N	{"at": "2026-07-16T03:22:33.887Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:22:41.771	4
cmrmy1eqz004wn43sttz938sh	ui.click	\N	{"at": "2026-07-16T03:22:34.703Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "บันทึกแผน"}	2026-07-16 03:22:41.771	4
cmrmy1eqz004xn43sivnfghxi	ui.click	\N	{"at": "2026-07-16T03:22:35.745Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080"}	2026-07-16 03:22:41.771	4
cmrmy1eqz004yn43scbuwf37k	ui.click	\N	{"at": "2026-07-16T03:22:36.355Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080"}	2026-07-16 03:22:41.771	4
cmrmy1eqz004zn43sk9pdgmo1	ui.click	\N	{"at": "2026-07-16T03:22:36.858Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "บันทึกแผน"}	2026-07-16 03:22:41.771	4
cmrmy1hvb0050n43sxn1bpg5o	ui.click	\N	{"at": "2026-07-16T03:22:39.766Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "+ เพิ่มแผน"}	2026-07-16 03:22:45.815	4
cmrmy1hvb0051n43scunwsm4u	ui.click	\N	{"at": "2026-07-16T03:22:40.899Z", "tag": "input", "page": "/dashboard", "label": "INPUT"}	2026-07-16 03:22:45.815	4
cmrmy1p7j0052n43sle5cjlom	ui.click	\N	{"at": "2026-07-16T03:22:43.409Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:22:55.327	4
cmrmy1p7j0053n43s1ncaf1um	ui.click	\N	{"at": "2026-07-16T03:22:44.012Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:22:55.327	4
cmrmy1p7j0054n43s2lfylo22	ui.click	\N	{"at": "2026-07-16T03:22:44.874Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080"}	2026-07-16 03:22:55.327	4
cmrmy1p7j0055n43s6z8tc7kh	ui.click	\N	{"at": "2026-07-16T03:22:45.531Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080"}	2026-07-16 03:22:55.327	4
cmrmy1p7j0056n43s1pm2p16i	ui.click	\N	{"at": "2026-07-16T03:22:46.508Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:22:55.327	4
cmrmy1p7j0057n43svybwkg0o	ui.click	\N	{"at": "2026-07-16T03:22:47.165Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:22:55.327	4
cmrmy1p7j0058n43skhdlht9u	ui.click	\N	{"at": "2026-07-16T03:22:48.513Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "บันทึกแผน"}	2026-07-16 03:22:55.327	4
cmrmy1p7j0059n43smx1ukgtr	ui.click	\N	{"at": "2026-07-16T03:22:49.551Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —"}	2026-07-16 03:22:55.327	4
cmrmy1p7j005an43sth5n0kz8	ui.click	\N	{"at": "2026-07-16T03:22:50.059Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —"}	2026-07-16 03:22:55.327	4
cmrmy1p7j005bn43sntstlddp	ui.click	\N	{"at": "2026-07-16T03:22:50.402Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —"}	2026-07-16 03:22:55.327	4
cmrmy1rr7005cn43spv17s051	ui.click	\N	{"at": "2026-07-16T03:22:51.962Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —"}	2026-07-16 03:22:58.628	4
cmrmy1rr7005dn43sns2ac1fn	ui.click	\N	{"at": "2026-07-16T03:22:52.552Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —"}	2026-07-16 03:22:58.628	4
cmrmy1rr7005en43sfnap27kz	ui.click	\N	{"at": "2026-07-16T03:22:53.713Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:22:58.628	4
cmrmy22nx005fn43srhs2ig9f	ui.click	\N	{"at": "2026-07-16T03:23:05.794Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:23:12.765	4
cmrmy22nx005gn43snyka1e27	ui.click	\N	{"at": "2026-07-16T03:23:06.995Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080"}	2026-07-16 03:23:12.765	4
cmrmy22nx005hn43suf6is0sv	ui.click	\N	{"at": "2026-07-16T03:23:07.829Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080"}	2026-07-16 03:23:12.765	4
cmrmy2ap8005jn43s7hjcyu25	workPlan.create	5	{"name": ".00000", "type": "3", "siteId": 1, "endDate": "2026-07-16T00:00:00.000Z", "startDate": "2026-07-16T00:00:00.000Z"}	2026-07-16 03:23:23.18	4
cmrmy2bul005kn43ss4659t4h	ui.click	\N	{"at": "2026-07-16T03:23:19.753Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "บันทึกแผน"}	2026-07-16 03:23:24.67	4
cmrmy2eix005ln43sk31g467u	ui.click	\N	{"at": "2026-07-16T03:23:21.706Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "16"}	2026-07-16 03:23:28.137	4
cmrmy2eix005mn43s5udw4q8m	ui.click	\N	{"at": "2026-07-16T03:23:22.631Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "16"}	2026-07-16 03:23:28.137	4
cmrmy2eix005nn43scb5bfhtt	ui.click	\N	{"at": "2026-07-16T03:23:23.020Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "16"}	2026-07-16 03:23:28.137	4
cmrmy2eix005on43s72euv311	ui.click	\N	{"at": "2026-07-16T03:23:23.223Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "16"}	2026-07-16 03:23:28.137	4
cmrmy2mlx005pn43sy0wgbttm	ui.click	\N	{"at": "2026-07-16T03:23:31.053Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "16"}	2026-07-16 03:23:38.613	4
cmrmy2mlx005qn43sc0e0mc3m	ui.click	\N	{"at": "2026-07-16T03:23:31.586Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "17"}	2026-07-16 03:23:38.613	4
cmrmy2mlx005rn43se985q274	ui.click	\N	{"at": "2026-07-16T03:23:31.769Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "17"}	2026-07-16 03:23:38.613	4
cmrmy2mlx005sn43s1sgi4zbd	ui.click	\N	{"at": "2026-07-16T03:23:32.316Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "15"}	2026-07-16 03:23:38.613	4
cmrmy2mlx005tn43syia5w0p1	ui.click	\N	{"at": "2026-07-16T03:23:32.485Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "15"}	2026-07-16 03:23:38.613	4
cmrmy2mlx005un43sxmvt4x9m	ui.click	\N	{"at": "2026-07-16T03:23:33.674Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "16"}	2026-07-16 03:23:38.613	4
cmrmy2nsy005vn43s4nrg3uxc	ui.click	\N	{"at": "2026-07-16T03:23:35.239Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "15"}	2026-07-16 03:23:40.162	4
cmrmy2p1m005wn43sk3wfvne0	ui.click	\N	{"at": "2026-07-16T03:23:36.851Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "16"}	2026-07-16 03:23:41.77	4
cmrmy2q8s005xn43s4s4hm7o5	ui.click	\N	{"at": "2026-07-16T03:23:38.405Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "17"}	2026-07-16 03:23:43.325	4
cmrmy4ht8005yn43schowbdpl	ui.click	\N	{"at": "2026-07-16T03:25:00.753Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "20"}	2026-07-16 03:25:05.708	4
cmrmy4mgp005zn43sdxwugn1p	ui.click	\N	{"at": "2026-07-16T03:25:03.687Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "23"}	2026-07-16 03:25:11.738	4
cmrmy4mgp0060n43szxo166qx	ui.click	\N	{"at": "2026-07-16T03:25:04.740Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "20"}	2026-07-16 03:25:11.738	4
cmrmy4mgq0061n43s4v4hfo94	ui.click	\N	{"at": "2026-07-16T03:25:06.081Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "20"}	2026-07-16 03:25:11.738	4
cmrmy4mgq0062n43sbltzz2cg	ui.click	\N	{"at": "2026-07-16T03:25:06.620Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "20"}	2026-07-16 03:25:11.738	4
cmrmy4mgq0063n43s1q1zht41	ui.click	\N	{"at": "2026-07-16T03:25:06.792Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "20"}	2026-07-16 03:25:11.738	4
cmrmy4old0064n43s9skjxynh	ui.click	\N	{"at": "2026-07-16T03:25:08.318Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "+ เพิ่มแผน"}	2026-07-16 03:25:14.497	4
cmrmy4old0065n43szhp5ll68	ui.click	\N	{"at": "2026-07-16T03:25:09.574Z", "tag": "input", "page": "/dashboard", "label": "INPUT"}	2026-07-16 03:25:14.497	4
cmrmy4qvm0066n43sfiw38uds	ui.click	\N	{"at": "2026-07-16T03:25:12.500Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:25:17.458	4
cmrmy4s1g0067n43s21bvvbtj	ui.click	\N	{"at": "2026-07-16T03:25:14.030Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-16 03:25:18.964	4
cmrmy5lec0068n43stverepz7	ui.click	\N	{"at": "2026-07-16T03:25:51.545Z", "tag": "input", "page": "/dashboard", "label": "INPUT"}	2026-07-16 03:25:57.012	4
cmrmy5led0069n43sfglljgjg	ui.click	\N	{"at": "2026-07-16T03:25:52.070Z", "tag": "input", "page": "/dashboard", "label": "INPUT"}	2026-07-16 03:25:57.012	4
cmrmy5o9d006bn43snvabuy5z	workPlan.create	6	{"name": "22222", "type": "1", "siteId": 1, "endDate": "2026-07-23T00:00:00.000Z", "startDate": "2026-07-20T00:00:00.000Z"}	2026-07-16 03:26:00.721	4
cmrmy5pet006cn43s1cqaei6w	ui.click	\N	{"at": "2026-07-16T03:25:55.079Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "บันทึกแผน"}	2026-07-16 03:26:02.214	4
cmrmy5peu006dn43sj5hz5740	ui.click	\N	{"at": "2026-07-16T03:25:56.033Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080"}	2026-07-16 03:26:02.214	4
cmrmy5peu006en43soru5jkc3	ui.click	\N	{"at": "2026-07-16T03:25:56.733Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080"}	2026-07-16 03:26:02.214	4
cmrmy5peu006fn43sp4lpf2vo	ui.click	\N	{"at": "2026-07-16T03:25:57.284Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "บันทึกแผน"}	2026-07-16 03:26:02.214	4
cmrmy5sss006gn43ssatlveoj	ui.click	\N	{"at": "2026-07-16T03:25:59.178Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "23"}	2026-07-16 03:26:06.605	4
cmrmy5sss006hn43ssnm1hsc9	ui.click	\N	{"at": "2026-07-16T03:25:59.653Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "20"}	2026-07-16 03:26:06.605	4
cmrmy5sss006in43sr5c2sp9s	ui.click	\N	{"at": "2026-07-16T03:26:00.301Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "20"}	2026-07-16 03:26:06.605	4
cmrmy5sss006jn43sdkg6az7f	ui.click	\N	{"at": "2026-07-16T03:26:01.511Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "20"}	2026-07-16 03:26:06.605	4
cmrmy5sss006kn43s6lezaf9w	ui.click	\N	{"at": "2026-07-16T03:26:01.671Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "20"}	2026-07-16 03:26:06.605	4
cmrmy6dvy006ln43sjwj2slns	ui.click	\N	{"at": "2026-07-16T03:26:27.555Z", "tag": "span.chip", "page": "/dashboard", "label": "ยังไม่เริ่ม"}	2026-07-16 03:26:33.927	4
cmrmy6dvy006mn43ssq68f86g	ui.click	\N	{"at": "2026-07-16T03:26:28.989Z", "tag": "div.plan-name", "page": "/dashboard", "label": "22222"}	2026-07-16 03:26:33.927	4
cmrmy6ve1006nn43sbgjju8qh	ui.click	\N	{"at": "2026-07-16T03:26:51.419Z", "tag": "div.plan-list", "page": "/dashboard", "label": "ผรม ลา16/07/2026 – 17/07/2026ยังไม่เริ่มเริ่มงาน000016/07/2026 – 16/07/2026ยังไม"}	2026-07-16 03:26:56.617	4
cmrmy6ve1006on43s69nv47b5	ui.click	\N	{"at": "2026-07-16T03:26:51.680Z", "tag": "div.plan-name", "page": "/dashboard", "label": "0000"}	2026-07-16 03:26:56.617	4
cmrmy6wut006pn43spsuu017s	ui.click	\N	{"at": "2026-07-16T03:26:53.417Z", "tag": "div.plan-row", "page": "/dashboard", "label": ".0000016/07/2026 – 16/07/2026ยังไม่เริ่มเริ่มงาน"}	2026-07-16 03:26:58.517	4
cmrmy7759006qn43swp4i866u	ui.click	\N	{"at": "2026-07-16T03:27:05.734Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "20"}	2026-07-16 03:27:11.853	4
cmrmy7759006rn43s1uxyei6o	ui.click	\N	{"at": "2026-07-16T03:27:06.752Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "20"}	2026-07-16 03:27:11.853	4
cmrmy7759006sn43swpii33m4	ui.click	\N	{"at": "2026-07-16T03:27:06.907Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "20"}	2026-07-16 03:27:11.853	4
cmrmy8ubp006tn43s49cdhjxy	ui.click	\N	{"at": "2026-07-16T03:28:23.550Z", "tag": "h2", "page": "/dashboard", "label": "แผนงาน — 20/07/2026"}	2026-07-16 03:28:28.549	4
cmrmy960t006un43se5bnhg2w	ui.click	\N	{"at": "2026-07-16T03:28:38.751Z", "tag": "section.day-panel", "page": "/dashboard", "label": "สรุปงานประจำวัน16/07/20260เลยกำหนดเริ่ม0เลยกำหนดจบ0กำลังทำ3ยังไม่เริ่ม1เสร็จแล้ว"}	2026-07-16 03:28:43.709	4
cmrmy9i9h006vn43s4zrj13m3	ui.click	\N	{"at": "2026-07-16T03:28:52.002Z", "tag": "div.sum-tile", "page": "/dashboard", "label": "0เลยกำหนดจบ"}	2026-07-16 03:28:59.574	4
cmrmy9i9h006wn43soni4wku6	ui.click	\N	{"at": "2026-07-16T03:28:53.466Z", "tag": "div.sum-label", "page": "/dashboard", "label": "เลยกำหนดเริ่ม"}	2026-07-16 03:28:59.574	4
cmrmy9i9h006xn43st3e7pokb	ui.click	\N	{"at": "2026-07-16T03:28:54.629Z", "tag": "div.sum-tile", "page": "/dashboard", "label": "0เลยกำหนดจบ"}	2026-07-16 03:28:59.574	4
cmrmy9oyq006yn43s2nw9dkwy	ui.click	\N	{"at": "2026-07-16T03:29:02.578Z", "tag": "div.sum-tile", "page": "/dashboard", "label": "0เลยกำหนดเริ่ม"}	2026-07-16 03:29:08.258	4
cmrmy9oyq006zn43skakux7a4	ui.click	\N	{"at": "2026-07-16T03:29:03.289Z", "tag": "div.sum-tile", "page": "/dashboard", "label": "0เลยกำหนดจบ"}	2026-07-16 03:29:08.258	4
cmrmy9qas0070n43syslxqjbc	ui.click	\N	{"at": "2026-07-16T03:29:05.045Z", "tag": "div.sum-tile", "page": "/dashboard", "label": "0เลยกำหนดจบ"}	2026-07-16 03:29:09.989	4
cmrmys76v0072n43sdfdredhj	LOGIN_FAILED	\N	{"ip": "172.19.0.1"}	2026-07-16 03:43:31.687	3
cmrmysaf10074n43sy5r1zvl9	LOGIN_FAILED	\N	{"ip": "172.19.0.1"}	2026-07-16 03:43:35.869	3
cmrmysg3h0076n43sjl1nfxco	auth.login	\N	\N	2026-07-16 03:43:43.229	3
cmrmysh7a0077n43slu98bsuh	ui.click	\N	{"at": "2026-07-16T03:43:40.133Z", "tag": "button", "page": "/", "label": "เข้าสู่ระบบ"}	2026-07-16 03:43:44.663	3
cmrmyt1xl0078n43s0vxhrxhy	ui.click	\N	{"at": "2026-07-16T03:44:06.973Z", "tag": "a.nav-item", "page": "/dashboard", "label": "ไซต์งาน"}	2026-07-16 03:44:11.53	3
cmrmyt4sl0079n43s4uv7raxz	ui.click	\N	{"at": "2026-07-16T03:44:10.564Z", "tag": "a.plan-row", "page": "/sites", "label": "0080Solar CellCCTVNetwork›"}	2026-07-16 03:44:15.237	3
cmrmyt7f6007an43s3tjdwu3j	ui.click	\N	{"at": "2026-07-16T03:44:14.102Z", "tag": "a.back-link", "page": "/sites/1", "label": "‹ กลับไปรายชื่อไซต์งาน"}	2026-07-16 03:44:18.643	3
cmrmytb8m007bn43sk64saopt	ui.click	\N	{"at": "2026-07-16T03:44:19.003Z", "tag": "a.nav-item", "page": "/sites", "label": "ประวัติการใช้งาน"}	2026-07-16 03:44:23.591	3
cmrmyto6o007cn43s840r5jht	ui.click	\N	{"at": "2026-07-16T03:44:35.831Z", "tag": "a.nav-item", "page": "/logs", "label": "งานของฉัน"}	2026-07-16 03:44:40.368	3
cmrprmn4f007en43skgsgah9q	auth.login	\N	\N	2026-07-18 02:46:33.615	4
cmrprmo60007fn43si57o0oc4	ui.click	\N	{"at": "2026-07-18T02:46:31.110Z", "tag": "button", "page": "/", "label": "เข้าสู่ระบบ"}	2026-07-18 02:46:34.969	4
cmrptz1w6007hn43stl1vj4s3	auth.login	\N	\N	2026-07-18 03:52:11.862	3
cmrptz2xg007in43sbyz5to52	ui.click	\N	{"at": "2026-07-18T03:52:09.189Z", "tag": "button", "page": "/", "label": "เข้าสู่ระบบ"}	2026-07-18 03:52:13.204	3
cmrptzcez007kn43sknn9bpvz	auth.login	\N	\N	2026-07-18 03:52:25.499	4
cmrptzmh5007mn43sdxkiebpe	auth.login	\N	\N	2026-07-18 03:52:38.537	4
cmrpu0nui007on43s7hzl2064	auth.login	\N	\N	2026-07-18 03:53:26.97	4
cmrpu0oyj007pn43sgylwk5ln	ui.click	\N	{"at": "2026-07-18T03:53:23.664Z", "tag": "button", "page": "/", "label": "เข้าสู่ระบบ"}	2026-07-18 03:53:28.411	4
cmrpu0yao007qn43s1f1fg4js	ui.click	\N	{"at": "2026-07-18T03:53:35.762Z", "tag": "span.chip", "page": "/dashboard", "label": "เลยกำหนดเริ่ม"}	2026-07-18 03:53:40.512	4
cmrpu14iz007rn43s318m7pw1	ui.click	\N	{"at": "2026-07-18T03:53:43.842Z", "tag": "button.btn-ghost", "page": "/dashboard", "label": "แก้ไข"}	2026-07-18 03:53:48.588	4
cmrpu183m007tn43smrnpjisd	workPlan.delete	2	{"id": 2}	2026-07-18 03:53:53.218	4
cmrpu199e007un43stn632vkv	ui.click	\N	{"at": "2026-07-18T03:53:48.535Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ลบแผนงาน"}	2026-07-18 03:53:54.722	4
cmrpu199e007vn43sdz774u5m	ui.click	\N	{"at": "2026-07-18T03:53:49.966Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ยืนยันลบแผนนี้?"}	2026-07-18 03:53:54.722	4
cmrpu1d7l007xn43s8q7f1pg1	workPlan.delete	4	{"id": 4}	2026-07-18 03:53:59.842	4
cmrpu1etv007zn43sgtwrsbzt	workPlan.delete	5	{"id": 5}	2026-07-18 03:54:01.94	4
cmrpu1gey0081n43scxh81eqp	workPlan.delete	6	{"id": 6}	2026-07-18 03:54:03.994	4
cmrpu1hwy0083n43sa3zmtmm6	workPlan.delete	3	{"id": 3}	2026-07-18 03:54:05.939	4
cmrpu1jz70084n43sz59he4br	ui.click	\N	{"at": "2026-07-18T03:53:53.869Z", "tag": "div.plan-name", "page": "/dashboard", "label": "0000"}	2026-07-18 03:54:08.611	4
cmrpu1jz70085n43sggc2yyzk	ui.click	\N	{"at": "2026-07-18T03:53:54.824Z", "tag": "button.btn-ghost", "page": "/dashboard", "label": "แก้ไข"}	2026-07-18 03:54:08.611	4
cmrpu1jz70086n43s6wh31uyk	ui.click	\N	{"at": "2026-07-18T03:53:55.999Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ลบแผนงาน"}	2026-07-18 03:54:08.611	4
cmrpu1jz70087n43snl6hnjtl	ui.click	\N	{"at": "2026-07-18T03:53:56.594Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ยืนยันลบแผนนี้?"}	2026-07-18 03:54:08.611	4
cmrpu1jz70088n43s2yhq4489	ui.click	\N	{"at": "2026-07-18T03:53:57.509Z", "tag": "button.btn-ghost", "page": "/dashboard", "label": "แก้ไข"}	2026-07-18 03:54:08.611	4
cmrpu1jz70089n43syc7v5u23	ui.click	\N	{"at": "2026-07-18T03:53:58.367Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ลบแผนงาน"}	2026-07-18 03:54:08.611	4
cmrpu1jz7008an43swtul435p	ui.click	\N	{"at": "2026-07-18T03:53:58.700Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ยืนยันลบแผนนี้?"}	2026-07-18 03:54:08.611	4
cmrpu1jz7008bn43s3pqoeug6	ui.click	\N	{"at": "2026-07-18T03:53:59.656Z", "tag": "button.btn-ghost", "page": "/dashboard", "label": "แก้ไข"}	2026-07-18 03:54:08.611	4
cmrpu1jz7008cn43s0234plkg	ui.click	\N	{"at": "2026-07-18T03:54:00.464Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ลบแผนงาน"}	2026-07-18 03:54:08.611	4
cmrpu1t85008kn43sibibuoiw	ui.click	\N	{"at": "2026-07-18T03:54:14.472Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "+ เพิ่มแผน"}	2026-07-18 03:54:20.597	4
cmrpu1jz7008dn43st0wfvel0	ui.click	\N	{"at": "2026-07-18T03:54:00.752Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ยืนยันลบแผนนี้?"}	2026-07-18 03:54:08.611	4
cmrpu1jz7008en43sc2zcd6vo	ui.click	\N	{"at": "2026-07-18T03:54:01.596Z", "tag": "button.btn-ghost", "page": "/dashboard", "label": "แก้ไข"}	2026-07-18 03:54:08.611	4
cmrpu1jz7008fn43sypg2e6fh	ui.click	\N	{"at": "2026-07-18T03:54:02.456Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ลบแผนงาน"}	2026-07-18 03:54:08.611	4
cmrpu1jz7008gn43ssog46r8u	ui.click	\N	{"at": "2026-07-18T03:54:02.692Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ยืนยันลบแผนนี้?"}	2026-07-18 03:54:08.611	4
cmrpu1jz7008hn43srjtrogez	ui.click	\N	{"at": "2026-07-18T03:54:03.425Z", "tag": "span.chip", "page": "/dashboard", "label": "เสร็จแล้ว"}	2026-07-18 03:54:08.611	4
cmrpu1jz7008in43sankt1pur	ui.click	\N	{"at": "2026-07-18T03:54:03.863Z", "tag": "span.chip", "page": "/dashboard", "label": "Solar Cell"}	2026-07-18 03:54:08.611	4
cmrpu1o3x008jn43sbmkebw2e	ui.click	\N	{"at": "2026-07-18T03:54:09.200Z", "tag": "div.plan-row", "page": "/dashboard", "label": "กำลัง16/07/2026 – 17/07/2026Solar Cellเสร็จแล้ว"}	2026-07-18 03:54:13.965	4
cmrpu1t85008ln43sjykqcy3c	ui.click	\N	{"at": "2026-07-18T03:54:15.842Z", "tag": "input", "page": "/dashboard", "label": "INPUT"}	2026-07-18 03:54:20.597	4
cmrpu28pe008mn43sui9nu7x3	ui.click	\N	{"at": "2026-07-18T03:54:33.248Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-18 03:54:40.657	4
cmrpu28pe008nn43s4vvn8tgb	ui.click	\N	{"at": "2026-07-18T03:54:34.490Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-18 03:54:40.657	4
cmrpu28pe008on43su705o4sf	ui.click	\N	{"at": "2026-07-18T03:54:35.882Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080"}	2026-07-18 03:54:40.657	4
cmrpu29vd008pn43stypt009p	ui.click	\N	{"at": "2026-07-18T03:54:37.423Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080"}	2026-07-18 03:54:42.17	4
cmrpu2bqm008qn43s87q4dz06	ui.click	\N	{"at": "2026-07-18T03:54:39.850Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080"}	2026-07-18 03:54:44.591	4
cmrpu2fil008rn43sndxs2x12	ui.click	\N	{"at": "2026-07-18T03:54:44.266Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080"}	2026-07-18 03:54:49.486	4
cmrpu2fil008sn43s1jds3zfw	ui.click	\N	{"at": "2026-07-18T03:54:44.715Z", "tag": "div.overlay", "page": "/dashboard", "label": "เพิ่มแผนงานชื่อแผนงานประเภทงาน— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-18 03:54:49.486	4
cmrpu2mh0008tn43sdrvomfus	ui.click	\N	{"at": "2026-07-18T03:54:53.738Z", "tag": "a.nav-item", "page": "/dashboard", "label": "ไซต์งาน"}	2026-07-18 03:54:58.5	4
cmrpu2opz008un43szhltk0jz	ui.click	\N	{"at": "2026-07-18T03:54:56.272Z", "tag": "section.day-panel", "page": "/sites", "label": "ไซต์งานทั้งหมด0080Solar CellCCTVNetwork›"}	2026-07-18 03:55:01.415	4
cmrpu2opz008vn43s795jdmds	ui.click	\N	{"at": "2026-07-18T03:54:56.653Z", "tag": "a.plan-row", "page": "/sites", "label": "0080Solar CellCCTVNetwork›"}	2026-07-18 03:55:01.415	4
cmrpu2ug5008wn43s1yt2ubf2	ui.click	\N	{"at": "2026-07-18T03:55:04.085Z", "tag": "span.chip", "page": "/sites/1", "label": "Solar Cell"}	2026-07-18 03:55:08.837	4
cmrpu2wck008xn43sjq8ab9i3	ui.click	\N	{"at": "2026-07-18T03:55:06.518Z", "tag": "button.title-edit", "page": "/sites/1", "label": "แก้ไขชื่อไซต์"}	2026-07-18 03:55:11.3	4
cmrpu2xxm008yn43smiozyv1i	ui.click	\N	{"at": "2026-07-18T03:55:08.606Z", "tag": "form.modal", "page": "/sites/1", "label": "แก้ไขชื่อไซต์งานชื่อไซต์งานยกเลิกบันทึก"}	2026-07-18 03:55:13.355	4
cmrpu2zuc008zn43ss39fx3o9	ui.click	\N	{"at": "2026-07-18T03:55:11.076Z", "tag": "button.btn-ghost", "page": "/sites/1", "label": "ยกเลิก"}	2026-07-18 03:55:15.828	4
cmrpu32a10090n43sw6yda46h	ui.click	\N	{"at": "2026-07-18T03:55:14.233Z", "tag": "a.back-link", "page": "/sites/1", "label": "‹ กลับไปรายชื่อไซต์งาน"}	2026-07-18 03:55:18.985	4
cmrpu34fd0091n43silg32kwt	ui.click	\N	{"at": "2026-07-18T03:55:15.963Z", "tag": "button.btn-primary", "page": "/sites", "label": "+ ไซต์งาน"}	2026-07-18 03:55:21.769	4
cmrpu34fd0092n43szmxad9nj	ui.click	\N	{"at": "2026-07-18T03:55:17.016Z", "tag": "input", "page": "/sites", "label": "INPUT"}	2026-07-18 03:55:21.769	4
cmrpu3ern0094n43sc7cn6a3r	site.create	2	{"name": "คุณอาร์ท ลำปาง", "typeIds": ["1"]}	2026-07-18 03:55:35.172	4
cmrpu3gpl0095n43s5gxcd0b9	ui.click	\N	{"at": "2026-07-18T03:55:31.214Z", "tag": "input", "page": "/sites", "label": "INPUT"}	2026-07-18 03:55:37.689	4
cmrpu3gpl0096n43smu6kqwbk	ui.click	\N	{"at": "2026-07-18T03:55:31.892Z", "tag": "button.btn-primary", "page": "/sites", "label": "บันทึกไซต์งาน"}	2026-07-18 03:55:37.689	4
cmrpu3gpl0097n43swxlp9ftx	ui.click	\N	{"at": "2026-07-18T03:55:32.939Z", "tag": "button.btn-primary", "page": "/sites", "label": "ปิด"}	2026-07-18 03:55:37.689	4
cmrpu3idl0098n43smzg66i97	ui.click	\N	{"at": "2026-07-18T03:55:35.105Z", "tag": "a.nav-item", "page": "/sites", "label": "งานของฉัน"}	2026-07-18 03:55:39.849	4
cmrpu3n3g0099n43s17sd5csg	ui.click	\N	{"at": "2026-07-18T03:55:38.597Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "+ เพิ่มแผน"}	2026-07-18 03:55:45.965	4
cmrpu3n3g009an43shuzrn5xf	ui.click	\N	{"at": "2026-07-18T03:55:40.076Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-18 03:55:45.965	4
cmrpu3n3g009bn43so43x5k6k	ui.click	\N	{"at": "2026-07-18T03:55:40.792Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-18 03:55:45.965	4
cmrpu3n3h009cn43sdqxhamnd	ui.click	\N	{"at": "2026-07-18T03:55:41.200Z", "tag": "input", "page": "/dashboard", "label": "INPUT"}	2026-07-18 03:55:45.965	4
cmrpu3r9o009dn43siuy1dgx4	ui.click	\N	{"at": "2026-07-18T03:55:45.566Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080#2 คุณอาร์ท ลำปาง"}	2026-07-18 03:55:51.372	4
cmrpu3r9o009en43s7pglnr99	ui.click	\N	{"at": "2026-07-18T03:55:46.622Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080#2 คุณอาร์ท ลำปาง"}	2026-07-18 03:55:51.372	4
cmrpu3vgf009fn43s4lxcfb9p	ui.click	\N	{"at": "2026-07-18T03:55:52.035Z", "tag": "input", "page": "/dashboard", "label": "INPUT"}	2026-07-18 03:55:56.798	4
cmrpu42my009hn43sto8p44vs	workPlan.create	7	{"name": "ถอดของ", "type": "1", "siteId": 2, "endDate": "2026-07-18T00:00:00.000Z", "startDate": "2026-07-18T00:00:00.000Z"}	2026-07-18 03:56:06.106	4
cmrpu43sn009in43suxtudsop	ui.click	\N	{"at": "2026-07-18T03:56:02.834Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "บันทึกแผน"}	2026-07-18 03:56:07.608	4
cmrpu48ap009kn43s7skw432x	workPlan.start	7	{"id": 7}	2026-07-18 03:56:13.441	4
cmrpu49ge009ln43shqjort14	ui.click	\N	{"at": "2026-07-18T03:56:10.185Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "เริ่มงาน"}	2026-07-18 03:56:14.942	4
cmrpu4akk009nn43s45k0sp7b	workPlan.unstart	7	{"id": 7}	2026-07-18 03:56:16.388	4
cmrpu4b50009pn43s92tcpc0i	workPlan.start	7	{"id": 7}	2026-07-18 03:56:17.124	4
cmrpu4can009qn43sw55f9rwn	ui.click	\N	{"at": "2026-07-18T03:56:12.029Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ยกเลิกเริ่มงาน"}	2026-07-18 03:56:18.623	4
cmrpu4can009rn43sy8anj4fe	ui.click	\N	{"at": "2026-07-18T03:56:13.128Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ยืนยันยกเลิก?"}	2026-07-18 03:56:18.623	4
cmrpu4can009sn43s833q38x3	ui.click	\N	{"at": "2026-07-18T03:56:13.875Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "เริ่มงาน"}	2026-07-18 03:56:18.623	4
cmrpu4ese009tn43sfotggehm	ui.click	\N	{"at": "2026-07-18T03:56:17.097Z", "tag": "div.plan-row", "page": "/dashboard", "label": "ถอดของ18/07/2026 – 18/07/2026กำลังทำจบงานยกเลิกเริ่มงาน"}	2026-07-18 03:56:21.854	4
cmrpu4hi1009un43sa9iy9gbr	ui.click	\N	{"at": "2026-07-18T03:56:20.619Z", "tag": "span.chip", "page": "/dashboard", "label": "กำลังทำ"}	2026-07-18 03:56:25.369	4
cmrpu4nhj009wn43syk5kd6d3	workPlan.unstart	7	{"id": 7}	2026-07-18 03:56:33.127	4
cmrpu4q4q00a1n43s05f4npp4	ui.click	\N	{"at": "2026-07-18T03:56:31.796Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "เริ่มงาน"}	2026-07-18 03:56:36.555	4
cmrpu4usu00a3n43sgp6adxi1	workPlan.unstart	7	{"id": 7}	2026-07-18 03:56:42.607	4
cmrpu50zw00acn43sbzjpcv7y	ui.click	\N	{"at": "2026-07-18T03:56:45.158Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ยกเลิกเริ่มงาน"}	2026-07-18 03:56:50.636	4
cmrpu50zw00adn43sqjt5xon2	ui.click	\N	{"at": "2026-07-18T03:56:45.856Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ยืนยันยกเลิก?"}	2026-07-18 03:56:50.636	4
cmrpu52dy00afn43shq2oehzo	workPlan.start	7	{"id": 7}	2026-07-18 03:56:52.439	4
cmrpu53jn00agn43szvclzybl	ui.click	\N	{"at": "2026-07-18T03:56:49.175Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "เริ่มงาน"}	2026-07-18 03:56:53.939	4
cmrpu4on1009xn43s83287zer	ui.click	\N	{"at": "2026-07-18T03:56:29.104Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ยกเลิกเริ่มงาน"}	2026-07-18 03:56:34.622	4
cmrpu4on1009yn43sw48nprnh	ui.click	\N	{"at": "2026-07-18T03:56:29.869Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ยืนยันยกเลิก?"}	2026-07-18 03:56:34.622	4
cmrpu4oz200a0n43sv8j3d9fw	workPlan.start	7	{"id": 7}	2026-07-18 03:56:35.054	4
cmrpu4vyo00a4n43ss5hxki2j	ui.click	\N	{"at": "2026-07-18T03:56:37.382Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "18"}	2026-07-18 03:56:44.112	4
cmrpu4vyo00a5n43s19l3kg5p	ui.click	\N	{"at": "2026-07-18T03:56:38.748Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ยกเลิกเริ่มงาน"}	2026-07-18 03:56:44.112	4
cmrpu4vyo00a6n43sf6evqtgx	ui.click	\N	{"at": "2026-07-18T03:56:39.349Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ยืนยันยกเลิก?"}	2026-07-18 03:56:44.112	4
cmrpu4xqu00a8n43sz98xrqbz	workPlan.start	7	{"id": 7}	2026-07-18 03:56:46.422	4
cmrpu4ywh00a9n43s4oklqxez	ui.click	\N	{"at": "2026-07-18T03:56:43.167Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "เริ่มงาน"}	2026-07-18 03:56:47.922	4
cmrpu4zts00abn43s7w2a1no7	workPlan.unstart	7	{"id": 7}	2026-07-18 03:56:49.121	4
cmrpu5qmm00ahn43s6ce10jow	ui.click	\N	{"at": "2026-07-18T03:57:19.718Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "28"}	2026-07-18 03:57:23.845	3
cmrpu5sto00ajn43s18mi59c4	auth.login	\N	\N	2026-07-18 03:57:26.7	3
cmrpu5ty300akn43sk2lb5ve8	ui.click	\N	{"at": "2026-07-18T03:57:24.114Z", "tag": "button", "page": "/", "label": "เข้าสู่ระบบ"}	2026-07-18 03:57:28.155	3
cmrpu66gp00aln43sdljs2lph	ui.click	\N	{"at": "2026-07-18T03:57:40.352Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "+ เพิ่มแผน"}	2026-07-18 03:57:44.377	3
cmrpu6cl700amn43sjf6k4vwf	ui.click	\N	{"at": "2026-07-18T03:57:45.347Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-18 03:57:52.315	3
cmrpu6cl700ann43s6qoyvkbx	ui.click	\N	{"at": "2026-07-18T03:57:45.996Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-18 03:57:52.315	3
cmrpu6cl700aon43sarlwcdpk	ui.click	\N	{"at": "2026-07-18T03:57:46.416Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-18 03:57:52.315	3
cmrpu6cl700apn43syykn8qsf	ui.click	\N	{"at": "2026-07-18T03:57:47.229Z", "tag": "option", "page": "/dashboard", "label": "Solar Cell"}	2026-07-18 03:57:52.315	3
cmrpu6cl700aqn43sgj9e3ojs	ui.click	\N	{"at": "2026-07-18T03:57:48.285Z", "tag": "select", "page": "/dashboard", "label": "— เลือกไซต์งาน —#1 0080#2 คุณอาร์ท ลำปาง"}	2026-07-18 03:57:52.315	3
cmrpu6g6q00arn43ssk5xe412	ui.click	\N	{"at": "2026-07-18T03:57:51.835Z", "tag": "div.modal-actions", "page": "/dashboard", "label": "ยกเลิกบันทึกแผน"}	2026-07-18 03:57:56.978	3
cmrpu6g6q00asn43s7fdtj3ue	ui.click	\N	{"at": "2026-07-18T03:57:52.941Z", "tag": "button.btn-ghost", "page": "/dashboard", "label": "ยกเลิก"}	2026-07-18 03:57:56.978	3
cmrpu6o9k00atn43skvyueftg	ui.click	\N	{"at": "2026-07-18T03:58:01.830Z", "tag": "a.nav-item", "page": "/dashboard", "label": "ไซต์งาน"}	2026-07-18 03:58:07.449	3
cmrpu6o9k00aun43s3i9vf61x	ui.click	\N	{"at": "2026-07-18T03:58:03.266Z", "tag": "a.plan-row", "page": "/sites", "label": "คุณอาร์ท ลำปางSolar Cell›"}	2026-07-18 03:58:07.449	3
cmrpu7cs000avn43se1by7io1	ui.click	\N	{"at": "2026-07-18T03:58:33.836Z", "tag": "a.back-link", "page": "/sites/2", "label": "‹ กลับไปรายชื่อไซต์งาน"}	2026-07-18 03:58:39.216	3
cmrpu7cs000awn43sbqp7lub8	ui.click	\N	{"at": "2026-07-18T03:58:35.182Z", "tag": "a.plan-row", "page": "/sites", "label": "0080Solar CellCCTVNetwork›"}	2026-07-18 03:58:39.216	3
cmrpu7qi100b1n43sagzpwjo6	ui.click	\N	{"at": "2026-07-18T03:58:52.970Z", "tag": "button", "page": "/", "label": "เข้าสู่ระบบ"}	2026-07-18 03:58:57.001	4
cmrpu7y7g00b2n43sxgowvx9g	ui.click	\N	{"at": "2026-07-18T03:59:02.952Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ยกเลิกเริ่มงาน"}	2026-07-18 03:59:06.988	4
cmrpu7y9e00b4n43sdbbhj32p	workPlan.unstart	7	{"id": 7}	2026-07-18 03:59:07.058	4
cmrpu7zeq00b5n43s7omhi4uh	ui.click	\N	{"at": "2026-07-18T03:59:04.512Z", "tag": "button.btn-danger", "page": "/dashboard", "label": "ยืนยันยกเลิก?"}	2026-07-18 03:59:08.546	4
cmrpu8dja00b6n43sg7wjttwu	ui.click	\N	{"at": "2026-07-18T03:59:22.744Z", "tag": "button.btn-ghost", "page": "/dashboard", "label": "แก้ไข"}	2026-07-18 03:59:26.855	4
cmrpu7i0c00axn43sszx3jfmd	ui.click	\N	{"at": "2026-07-18T03:58:40.875Z", "tag": "a.back-link", "page": "/sites/1", "label": "‹ กลับไปรายชื่อไซต์งาน"}	2026-07-18 03:58:45.996	3
cmrpu7i0c00ayn43s7k1da84w	ui.click	\N	{"at": "2026-07-18T03:58:41.957Z", "tag": "a.plan-row", "page": "/sites", "label": "คุณอาร์ท ลำปางSolar Cell›"}	2026-07-18 03:58:45.996	3
cmrpu7pfz00b0n43sg6rhobj3	auth.login	\N	\N	2026-07-18 03:58:55.631	4
cmrpus6oc00b7n43sml3aqblq	ui.click	\N	{"at": "2026-07-18T04:14:46.955Z", "tag": "button.btn-ghost", "page": "/dashboard", "label": "ยกเลิก"}	2026-07-18 04:14:51.076	4
cmrpusd0m00b8n43sz9reac1f	ui.click	\N	{"at": "2026-07-18T04:14:52.447Z", "tag": "button.bell-btn", "page": "/dashboard", "label": "การแจ้งเตือน"}	2026-07-18 04:14:59.302	4
cmrpusd0m00b9n43silg57bhm	ui.click	\N	{"at": "2026-07-18T04:14:53.241Z", "tag": "button.bell-btn", "page": "/dashboard", "label": "การแจ้งเตือน"}	2026-07-18 04:14:59.302	4
cmrpusd0m00ban43srehd6zpi	ui.click	\N	{"at": "2026-07-18T04:14:53.460Z", "tag": "button.bell-btn", "page": "/dashboard", "label": "การแจ้งเตือน"}	2026-07-18 04:14:59.302	4
cmrpusd0m00bbn43sb0z1olsk	ui.click	\N	{"at": "2026-07-18T04:14:53.656Z", "tag": "button.bell-btn", "page": "/dashboard", "label": "การแจ้งเตือน"}	2026-07-18 04:14:59.302	4
cmrpusd0m00bcn43sajuiflfg	ui.click	\N	{"at": "2026-07-18T04:14:54.637Z", "tag": "button.bell-btn", "page": "/dashboard", "label": "การแจ้งเตือน"}	2026-07-18 04:14:59.302	4
cmrpusd0m00bdn43s6wiwbx3c	ui.click	\N	{"at": "2026-07-18T04:14:54.767Z", "tag": "button.bell-btn", "page": "/dashboard", "label": "การแจ้งเตือน"}	2026-07-18 04:14:59.302	4
cmrpusd0m00ben43sp03naha0	ui.click	\N	{"at": "2026-07-18T04:14:54.939Z", "tag": "button.bell-btn", "page": "/dashboard", "label": "การแจ้งเตือน"}	2026-07-18 04:14:59.302	4
cmrpuwwvg00bfn43sf7ms4nh1	ui.click	\N	{"at": "2026-07-18T04:18:27.569Z", "tag": "a.nav-item", "page": "/dashboard", "label": "ประวัติการใช้งาน"}	2026-07-18 04:18:31.661	4
cmrpux0p000bgn43secu53zkz	ui.click	\N	{"at": "2026-07-18T04:18:32.543Z", "tag": "a.nav-item", "page": "/logs", "label": "งานของฉัน"}	2026-07-18 04:18:36.613	4
cmrpvwf6d00bin43s95ddyzos	auth.login	\N	\N	2026-07-18 04:46:08.341	3
cmrpvwgak00bjn43sp4d6u8zw	ui.click	\N	{"at": "2026-07-18T04:46:05.631Z", "tag": "button", "page": "/", "label": "เข้าสู่ระบบ"}	2026-07-18 04:46:09.788	3
cmrq3ggmk0000qq3sw9j6wfrk	ui.click	\N	{"at": "2026-07-18T08:17:39.515Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "+ เพิ่มแผน"}	2026-07-18 08:17:40.652	3
cmrq3hct90001qq3s98i4mx9c	ui.click	\N	{"at": "2026-07-18T08:18:21.324Z", "tag": "button.btn-ghost", "page": "/dashboard", "label": "ยกเลิก"}	2026-07-18 08:18:22.365	3
cmrq3hiil0002qq3s333gr239	ui.click	\N	{"at": "2026-07-18T08:18:28.759Z", "tag": "a.plan-row", "page": "/sites", "label": "0080Solar CellCCTVNetwork›"}	2026-07-18 08:18:29.758	3
cmrq3htio0003qq3sjdosec8w	ui.click	\N	{"at": "2026-07-18T08:18:43.024Z", "tag": "a.back-link", "page": "/sites/1", "label": "‹ กลับไปรายชื่อไซต์งาน"}	2026-07-18 08:18:44.017	3
cmrq3hwxl0004qq3s0cnwnm4m	ui.click	\N	{"at": "2026-07-18T08:18:47.374Z", "tag": "button.btn-primary", "page": "/sites", "label": "+ ไซต์งาน"}	2026-07-18 08:18:48.441	3
cmrq3hyi20005qq3sr0jvsluj	ui.click	\N	{"at": "2026-07-18T08:18:49.464Z", "tag": "label.check-item", "page": "/sites", "label": "Software"}	2026-07-18 08:18:50.475	3
cmrq3hyi20006qq3sc15e6efx	ui.click	\N	{"at": "2026-07-18T08:18:49.464Z", "tag": "input", "page": "/sites", "label": "INPUT"}	2026-07-18 08:18:50.475	3
cmrq3i0qf0007qq3sar9nc75e	ui.click	\N	{"at": "2026-07-18T08:18:52.254Z", "tag": "input", "page": "/sites", "label": "INPUT"}	2026-07-18 08:18:53.367	3
cmrq3iaei0009qq3s6yhteg6n	site.create	3	{"name": "Be Connected.com", "typeIds": ["5"]}	2026-07-18 08:19:05.898	3
cmrq3icot000aqq3s5ht9al1l	ui.click	\N	{"at": "2026-07-18T08:19:06.400Z", "tag": "button.btn-primary", "page": "/sites", "label": "บันทึกไซต์งาน"}	2026-07-18 08:19:08.861	3
cmrq3icot000bqq3stabl1c8f	ui.click	\N	{"at": "2026-07-18T08:19:07.865Z", "tag": "button.btn-primary", "page": "/sites", "label": "ปิด"}	2026-07-18 08:19:08.861	3
cmrq3ijpv000cqq3scbzguu3n	ui.click	\N	{"at": "2026-07-18T08:19:16.990Z", "tag": "a.nav-item", "page": "/sites", "label": "งานของฉัน"}	2026-07-18 08:19:17.971	3
cmrq3im6u000dqq3s6dyw97ww	ui.click	\N	{"at": "2026-07-18T08:19:20.068Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "+ เพิ่มแผน"}	2026-07-18 08:19:21.174	3
cmrq3j6zq000eqq3skf1mtn86	ui.click	\N	{"at": "2026-07-18T08:19:47.132Z", "tag": "select", "page": "/dashboard", "label": "— เลือกประเภทงาน —Solar CellCCTVNetworkIOTSoftware"}	2026-07-18 08:19:48.134	3
cmrq3j9ai000fqq3sr9f83tfi	ui.click	\N	{"at": "2026-07-18T08:19:50.115Z", "tag": "option", "page": "/dashboard", "label": "Software"}	2026-07-18 08:19:51.114	3
cmrq3jaka000gqq3s0xnsj1ld	ui.click	\N	{"at": "2026-07-18T08:19:51.754Z", "tag": "option", "page": "/dashboard", "label": "#3 Be Connected.com"}	2026-07-18 08:19:52.763	3
cmrq3jpjr000iqq3s5itb55ld	workPlan.create	8	{"name": "ทำ ticket สำหรับการส่งงาน", "type": "5", "siteId": 3, "endDate": "2026-07-18T00:00:00.000Z", "startDate": "2026-07-18T00:00:00.000Z"}	2026-07-18 08:20:12.183	3
cmrq3jqoz000jqq3sy3fxzkec	ui.click	\N	{"at": "2026-07-18T08:20:12.675Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "บันทึกแผน"}	2026-07-18 08:20:13.667	3
cmrq3jtwc000lqq3sjpo1iyy8	workPlan.start	8	{"id": 8}	2026-07-18 08:20:17.82	3
cmrq3jv1w000mqq3sr15bbc66	ui.click	\N	{"at": "2026-07-18T08:20:18.322Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "เริ่มงาน"}	2026-07-18 08:20:19.316	3
cmrq3kfmj000nqq3sqiuz64lj	ui.click	\N	{"at": "2026-07-18T08:20:41.940Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "+ เพิ่มแผน"}	2026-07-18 08:20:45.979	3
cmrq3kt05000oqq3shyl7il6j	ui.click	\N	{"at": "2026-07-18T08:21:02.304Z", "tag": "button.btn-ghost", "page": "/dashboard", "label": "ยกเลิก"}	2026-07-18 08:21:03.316	3
cmrsn7sk10001qq3s577pvahu	auth.login	\N	\N	2026-07-20 03:06:20.881	3
cmrsn7tmd0002qq3sixjaqrr7	ui.click	\N	{"at": "2026-07-20T03:06:20.744Z", "tag": "button", "page": "/", "label": "เข้าสู่ระบบ"}	2026-07-20 03:06:22.261	3
cmrsn81gz0003qq3s13ychazd	ui.click	\N	{"at": "2026-07-20T03:06:30.882Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "จบงาน"}	2026-07-20 03:06:32.435	3
cmrsn86l60004qq3sqnlwrtph	ui.click	\N	{"at": "2026-07-20T03:06:37.551Z", "tag": "button.btn-ghost", "page": "/dashboard", "label": "ยกเลิก"}	2026-07-20 03:06:39.066	3
cmrsniwdy0005qq3se7nq8sg9	ui.click	\N	{"at": "2026-07-20T03:14:57.424Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "จบงาน"}	2026-07-20 03:14:59.062	3
cmrsnjg0o0006qq3s7nkeq6m9	ui.click	\N	{"at": "2026-07-20T03:15:21.642Z", "tag": "textarea", "page": "/dashboard", "label": "ลืมกดจบ"}	2026-07-20 03:15:24.504	3
cmrsnjg0o0007qq3skk6gsstw	ui.click	\N	{"at": "2026-07-20T03:15:22.983Z", "tag": "button.btn-ghost", "page": "/dashboard", "label": "ยกเลิก"}	2026-07-20 03:15:24.504	3
cmrsq0pzw0009qq3scqlu0gq6	auth.login	\N	\N	2026-07-20 04:24:49.82	2
cmrsq0r3f000aqq3sphzmujdl	ui.click	\N	{"at": "2026-07-20T04:24:49.731Z", "tag": "button", "page": "/", "label": "เข้าสู่ระบบ"}	2026-07-20 04:24:51.243	2
cmrsq10um000cqq3sm39iduns	auth.login	\N	\N	2026-07-20 04:25:03.886	4
cmrsq12z8000dqq3smka7fzs8	ui.click	\N	{"at": "2026-07-20T04:25:03.793Z", "tag": "button", "page": "/", "label": "เข้าสู่ระบบ"}	2026-07-20 04:25:06.644	4
cmrsq12z8000eqq3s1y7m0rgn	ui.click	\N	{"at": "2026-07-20T04:25:05.107Z", "tag": "header.topbar", "page": "/dashboard", "label": "งานของฉัน"}	2026-07-20 04:25:06.644	4
cmrswhbde000gqq3sctos9ine	auth.login	\N	\N	2026-07-20 07:25:41.713	3
cmrswhcj8000hqq3sjkk7ok9a	ui.click	\N	{"at": "2026-07-20T07:25:39.558Z", "tag": "button.logout-btn", "page": "/dashboard", "label": "ออกจากระบบ"}	2026-07-20 07:25:43.221	3
cmrswhcj8000iqq3sjg65pjh0	ui.click	\N	{"at": "2026-07-20T07:25:40.345Z", "tag": "input", "page": "/", "label": "INPUT"}	2026-07-20 07:25:43.221	3
cmrswhcj8000jqq3sxs38popz	ui.click	\N	{"at": "2026-07-20T07:25:41.639Z", "tag": "button", "page": "/", "label": "เข้าสู่ระบบ"}	2026-07-20 07:25:43.221	3
cmrubfeo7000lqq3skg4lox5m	auth.login	\N	\N	2026-07-21 07:11:53.095	3
cmrubffp8000mqq3spgfuwwhi	ui.click	\N	{"at": "2026-07-21T07:11:51.617Z", "tag": "input", "page": "/", "label": "INPUT"}	2026-07-21 07:11:54.428	3
cmrubffp8000nqq3sliowpqet	ui.click	\N	{"at": "2026-07-21T07:11:52.914Z", "tag": "button", "page": "/", "label": "เข้าสู่ระบบ"}	2026-07-21 07:11:54.428	3
cmrviu6nq0001qq3sydlu162o	auth.login	\N	\N	2026-07-22 03:27:06.038	3
cmrviu7pl0002qq3s9l7hzpiq	ui.click	\N	{"at": "2026-07-22T03:27:04.378Z", "tag": "input", "page": "/", "label": "INPUT"}	2026-07-22 03:27:07.401	3
cmrviu7pl0003qq3sjyf57096	ui.click	\N	{"at": "2026-07-22T03:27:05.883Z", "tag": "button", "page": "/", "label": "เข้าสู่ระบบ"}	2026-07-22 03:27:07.401	3
cmrviua5h0004qq3s0lzbivl0	ui.click	\N	{"at": "2026-07-22T03:27:08.058Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "จบงาน"}	2026-07-22 03:27:10.566	3
cmrviua5h0005qq3s84yprmo1	ui.click	\N	{"at": "2026-07-22T03:27:08.939Z", "tag": "textarea", "page": "/dashboard", "label": "TEXTAREA"}	2026-07-22 03:27:10.566	3
cmrviuhu00006qq3skkv6ocjm	ui.click	\N	{"at": "2026-07-22T03:27:19.006Z", "tag": "textarea", "page": "/dashboard", "label": "TEXTAREA"}	2026-07-22 03:27:20.521	3
cmrvivf0w0008qq3s49vyeh91	workPlan.finish	8	{"id": 8, "delayEndReason": "ออกหน้างาน+ไม่ได้วางแผน db แต่แรก"}	2026-07-22 03:28:03.536	3
cmrvivg990009qq3sgvwx1mf1	ui.click	\N	{"at": "2026-07-22T03:28:03.518Z", "tag": "button.btn-primary", "page": "/dashboard", "label": "บันทึกและจบงาน"}	2026-07-22 03:28:05.133	3
cmrvivopp000aqq3syqllyv56	ui.click	\N	{"at": "2026-07-22T03:28:14.532Z", "tag": "span.day-num", "page": "/dashboard", "label": "18"}	2026-07-22 03:28:16.093	3
cmrvivr1k000bqq3suqx72eiq	ui.click	\N	{"at": "2026-07-22T03:28:17.603Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "18"}	2026-07-22 03:28:19.112	3
cmrvivt1k000cqq3sdavkoa1t	ui.click	\N	{"at": "2026-07-22T03:28:20.186Z", "tag": "div.cal-cell", "page": "/dashboard", "label": "22"}	2026-07-22 03:28:21.704	3
cmrviw731000dqq3sws5nw7u7	ui.click	\N	{"at": "2026-07-22T03:28:32.633Z", "tag": "a.nav-item", "page": "/dashboard", "label": "ไซต์งาน"}	2026-07-22 03:28:39.901	3
cmrviw731000eqq3szam1jcco	ui.click	\N	{"at": "2026-07-22T03:28:33.631Z", "tag": "a.nav-item", "page": "/sites", "label": "ประวัติการใช้งาน"}	2026-07-22 03:28:39.901	3
cmrviw731000fqq3sutz74vyr	ui.click	\N	{"at": "2026-07-22T03:28:35.037Z", "tag": "div.nav-item", "page": "/logs", "label": "คลังอุปกรณ์"}	2026-07-22 03:28:39.901	3
cmrviw731000gqq3siz2dx41q	ui.click	\N	{"at": "2026-07-22T03:28:36.519Z", "tag": "a.nav-item", "page": "/logs", "label": "ไซต์งาน"}	2026-07-22 03:28:39.901	3
cmrviw731000hqq3sp8u5k76n	ui.click	\N	{"at": "2026-07-22T03:28:37.210Z", "tag": "a.nav-item", "page": "/sites", "label": "งานของฉัน"}	2026-07-22 03:28:39.901	3
cmrviw731000iqq3sxpacseuy	ui.click	\N	{"at": "2026-07-22T03:28:38.053Z", "tag": "a.nav-item", "page": "/dashboard", "label": "ไซต์งาน"}	2026-07-22 03:28:39.901	3
cmrviw731000jqq3sfbecddqk	ui.click	\N	{"at": "2026-07-22T03:28:38.383Z", "tag": "a.nav-item", "page": "/sites", "label": "ประวัติการใช้งาน"}	2026-07-22 03:28:39.901	3
cmrviwdai000kqq3sq9gmxr7x	ui.click	\N	{"at": "2026-07-22T03:28:46.433Z", "tag": "a.nav-item", "page": "/logs", "label": "งานของฉัน"}	2026-07-22 03:28:47.946	3
\.


--
-- Data for Name: sites; Type: TABLE DATA; Schema: public; Owner: beconnected
--

COPY public.sites (name, id) FROM stdin;
0080	1
คุณอาร์ท ลำปาง	2
Be Connected.com	3
\.


--
-- Data for Name: types; Type: TABLE DATA; Schema: public; Owner: beconnected
--

COPY public.types (id, name) FROM stdin;
1	Solar Cell
2	CCTV
3	Network
4	IOT
5	Software
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: beconnected
--

COPY public.users (username, "passwordHash", name, role, color, id) FROM stdin;
nongnoom	$2a$10$714c1NAmgvaSOiEZy.jPZuykxrQw.V.AH.inzYVYuyReKjLvPvQ72	nongnoom	CEO	#6366f1	1
tawan	$2a$10$714c1NAmgvaSOiEZy.jPZuykxrQw.V.AH.inzYVYuyReKjLvPvQ72	Tawan	ENGINEER	#0ea5e9	2
earth	$2a$10$714c1NAmgvaSOiEZy.jPZuykxrQw.V.AH.inzYVYuyReKjLvPvQ72	Earth	ENGINEER	#f59e0b	3
ohm	$2a$10$714c1NAmgvaSOiEZy.jPZuykxrQw.V.AH.inzYVYuyReKjLvPvQ72	Ohm	ENGINEER	#10b981	4
\.


--
-- Data for Name: work_plans; Type: TABLE DATA; Schema: public; Owner: beconnected
--

COPY public.work_plans ("siteId", name, "startDate", "endDate", "actStart", "actEnd", "delayStartReason", "delayEndReason", "createdAt", "updatedAt", type, id, "userId") FROM stdin;
1	กำลัง	2026-07-16	2026-07-17	2026-07-16 03:05:57.225	2026-07-16 03:07:35.349	\N	\N	2026-07-16 03:05:27.385	2026-07-16 03:07:35.35	1	1	4
2	ถอดของ	2026-07-18	2026-07-18	\N	\N	\N	\N	2026-07-18 03:56:06.103	2026-07-18 03:59:07.056	1	7	4
3	ทำ ticket สำหรับการส่งงาน	2026-07-18	2026-07-18	2026-07-18 08:20:17.814	2026-07-22 03:28:03.528	\N	ออกหน้างาน+ไม่ได้วางแผน db แต่แรก	2026-07-18 08:20:12.179	2026-07-22 03:28:03.529	5	8	3
\.


--
-- Name: sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: beconnected
--

SELECT pg_catalog.setval('public.sites_id_seq', 3, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: beconnected
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: work_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: beconnected
--

SELECT pg_catalog.setval('public.work_plans_id_seq', 8, true);


--
-- Name: _SiteToType _SiteToType_AB_pkey; Type: CONSTRAINT; Schema: public; Owner: beconnected
--

ALTER TABLE ONLY public."_SiteToType"
    ADD CONSTRAINT "_SiteToType_AB_pkey" PRIMARY KEY ("A", "B");


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: beconnected
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: beconnected
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: sites sites_pkey; Type: CONSTRAINT; Schema: public; Owner: beconnected
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_pkey PRIMARY KEY (id);


--
-- Name: types types_pkey; Type: CONSTRAINT; Schema: public; Owner: beconnected
--

ALTER TABLE ONLY public.types
    ADD CONSTRAINT types_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: beconnected
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: work_plans work_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: beconnected
--

ALTER TABLE ONLY public.work_plans
    ADD CONSTRAINT work_plans_pkey PRIMARY KEY (id);


--
-- Name: _SiteToType_B_index; Type: INDEX; Schema: public; Owner: beconnected
--

CREATE INDEX "_SiteToType_B_index" ON public."_SiteToType" USING btree ("B");


--
-- Name: audit_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: beconnected
--

CREATE INDEX "audit_logs_createdAt_idx" ON public.audit_logs USING btree ("createdAt");


--
-- Name: audit_logs_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: beconnected
--

CREATE INDEX "audit_logs_userId_createdAt_idx" ON public.audit_logs USING btree ("userId", "createdAt");


--
-- Name: types_name_key; Type: INDEX; Schema: public; Owner: beconnected
--

CREATE UNIQUE INDEX types_name_key ON public.types USING btree (name);


--
-- Name: users_username_key; Type: INDEX; Schema: public; Owner: beconnected
--

CREATE UNIQUE INDEX users_username_key ON public.users USING btree (username);


--
-- Name: work_plans_siteId_idx; Type: INDEX; Schema: public; Owner: beconnected
--

CREATE INDEX "work_plans_siteId_idx" ON public.work_plans USING btree ("siteId");


--
-- Name: work_plans_startDate_endDate_idx; Type: INDEX; Schema: public; Owner: beconnected
--

CREATE INDEX "work_plans_startDate_endDate_idx" ON public.work_plans USING btree ("startDate", "endDate");


--
-- Name: work_plans_userId_startDate_idx; Type: INDEX; Schema: public; Owner: beconnected
--

CREATE INDEX "work_plans_userId_startDate_idx" ON public.work_plans USING btree ("userId", "startDate");


--
-- Name: _SiteToType _SiteToType_A_fkey; Type: FK CONSTRAINT; Schema: public; Owner: beconnected
--

ALTER TABLE ONLY public."_SiteToType"
    ADD CONSTRAINT "_SiteToType_A_fkey" FOREIGN KEY ("A") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _SiteToType _SiteToType_B_fkey; Type: FK CONSTRAINT; Schema: public; Owner: beconnected
--

ALTER TABLE ONLY public."_SiteToType"
    ADD CONSTRAINT "_SiteToType_B_fkey" FOREIGN KEY ("B") REFERENCES public.types(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: beconnected
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: work_plans work_plans_siteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: beconnected
--

ALTER TABLE ONLY public.work_plans
    ADD CONSTRAINT "work_plans_siteId_fkey" FOREIGN KEY ("siteId") REFERENCES public.sites(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: work_plans work_plans_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: beconnected
--

ALTER TABLE ONLY public.work_plans
    ADD CONSTRAINT work_plans_type_fkey FOREIGN KEY (type) REFERENCES public.types(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: work_plans work_plans_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: beconnected
--

ALTER TABLE ONLY public.work_plans
    ADD CONSTRAINT "work_plans_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict CxG3AiBeGwc73KmuLesFVx76P1pr3wCTBDx2O3KfYCvuaBOWhDRBOeX3vpaWXP2

